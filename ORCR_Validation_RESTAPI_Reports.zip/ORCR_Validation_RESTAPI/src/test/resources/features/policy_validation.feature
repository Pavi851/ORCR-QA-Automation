Feature: ORCR insurance policy validation
  As a user of the ORCR insurance page
  I want to validate the policy options
  So that the insurance page behaves as expected

  Scenario: INS_001 - Verify insurance page URL
    Given I open the insurance page
    Then the page URL should contain "/insurance"

  Scenario: INS_002 - Verify View Plan button is disabled initially
    Given I open the insurance page
    Then the View Plan button should be disabled

  Scenario: INS_003 - Verify Health Insurance option is available
    Given I open the insurance page
    Then the category dropdown should contain "Health Insurance"

  Scenario: INS_004 - Verify Buy New Policy link is visible
    Given I open the insurance page
    Then the Buy New Policy link should be visible

  Scenario: INS_005 - Select Health Insurance category
    Given I open the insurance page
    When I select the category "Health Insurance"
    Then the selected category should be "Health Insurance"

  @intentional-failure
  Scenario: INTENTIONAL FAILURE 1 - Demonstrate incorrect URL expectation
    Given I open the insurance page
    Then the page URL should equal "https://example.invalid/this-url-is-intentionally-wrong"

  @intentional-failure
  Scenario: INTENTIONAL FAILURE 2 - Demonstrate incorrect title expectation
    Given I open the insurance page
    Then the page title should equal "Definitely Not the Actual Page Title"
