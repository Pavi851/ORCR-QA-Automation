package stepdefinitions;

import hooks.ScenarioHooks;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import org.testng.Assert;
import pages.InsurancePage;

public class PolicyStepDefinitions {
    private InsurancePage page() { return ScenarioHooks.page(); }

    @Given("I open the insurance page")
    public void i_open_the_insurance_page() {
        Assert.assertTrue(page().getCurrentUrl().contains("/insurance"),
                "Insurance page should open");
    }

    @Then("the page URL should contain {string}")
    public void page_url_should_contain(String expected) {
        Assert.assertTrue(page().getCurrentUrl().contains(expected),
                "Expected URL to contain: " + expected);
    }

    @Then("the View Plan button should be disabled")
    public void view_plan_button_should_be_disabled() {
        Assert.assertFalse(page().isViewPlanButtonEnabled(),
                "View Plan Details button should be disabled initially");
    }

    @Then("the category dropdown should contain {string}")
    public void category_dropdown_should_contain(String option) {
        Assert.assertTrue(page().hasCategoryOption(option),
                "Category dropdown should contain " + option);
    }

    @Then("the Buy New Policy link should be visible")
    public void buy_new_policy_link_should_be_visible() {
        Assert.assertTrue(page().isBuyNewPolicyLinkDisplayed(),
                "Buy New Policy link should be visible");
    }

    @When("I select the category {string}")
    public void select_category(String category) {
        page().selectCategory(category);
    }

    @Then("the selected category should be {string}")
    public void selected_category_should_be(String expected) {
        Assert.assertEquals(page().getSelectedCategory(), expected,
                "Selected category should match");
    }

    @Then("the page URL should equal {string}")
    public void page_url_should_equal(String expected) {
        Assert.assertEquals(page().getCurrentUrl(), expected,
                "Intentional failure: URL expectation is deliberately incorrect");
    }

    @Then("the page title should equal {string}")
    public void page_title_should_equal(String expected) {
        Assert.assertEquals(page().getPageTitle(), expected,
                "Intentional failure: title expectation is deliberately incorrect");
    }
}
