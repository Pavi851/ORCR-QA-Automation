package tests;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import pages.InsurancePage;

public class InsuranceTests extends BaseTest {
    private InsurancePage insurancePage;

    @BeforeMethod(alwaysRun = true)
    public void initializePageObject() {
        insurancePage = new InsurancePage(driver);
    }

    // INS_001: Verify insurance page URL.
    @Test
    public void verifyPageURL() {
        Assert.assertTrue(insurancePage.getCurrentUrl().contains("/insurance"),
                "Insurance page should open");
    }

    // INS_002: Verify View Plan Details button is disabled initially.
    @Test
    public void verifyViewPlanButtonDisabledInitially() {
        Assert.assertFalse(insurancePage.isViewPlanButtonEnabled(),
                "View Plan Details button should be disabled initially");
    }

    // INS_003: Verify Health Insurance option is available.
    @Test
    public void verifyHealthInsuranceOptionPresent() {
        Assert.assertTrue(insurancePage.hasCategoryOption("Health Insurance"),
                "Health Insurance option should be present in the dropdown");
    }

    // INS_004: Verify Buy New Policy link is visible.
    @Test
    public void verifyBuyNewPolicyLink() {
        Assert.assertTrue(insurancePage.isBuyNewPolicyLinkDisplayed(),
                "Buy New Policy link should be visible");
    }

    // INS_005: Verify selecting Health Insurance.
    @Test
    public void selectHealthInsuranceCategory() {
        insurancePage.selectCategory("Health Insurance");
        Assert.assertEquals(insurancePage.getSelectedCategory(), "Health Insurance",
                "Selected category should be Health Insurance");
    }

    // INTENTIONAL FAILURE 1: Demonstrates a failed assertion in the report.
    // Remove this test or change the expected value for a normal passing run.
    @Test(description = "INTENTIONAL FAILURE 1 - demo/report validation")
    public void intentionalFailure_wrongPageUrlExpectation() {
        Assert.assertEquals(insurancePage.getCurrentUrl(),
                "https://example.invalid/this-url-is-intentionally-wrong",
                "Intentional failure: expected URL is deliberately incorrect");
    }

    // INTENTIONAL FAILURE 2: Demonstrates another failed assertion in the report.
    // Remove this test or change the expected value for a normal passing run.
    @Test(description = "INTENTIONAL FAILURE 2 - demo/report validation")
    public void intentionalFailure_wrongTitleExpectation() {
        Assert.assertEquals(insurancePage.getPageTitle(),
                "Definitely Not the Actual Page Title",
                "Intentional failure: expected title is deliberately incorrect");
    }
}
