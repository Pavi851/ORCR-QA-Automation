package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.time.Duration;
import java.util.List;

public class ReusableValidator {

    private final WebDriver driver;
    private final WebDriverWait wait;

    public ReusableValidator(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(
                driver, Duration.ofSeconds(10));
    }

    public WebElement waitForVisible(By locator) {
        return wait.until(
                ExpectedConditions
                        .visibilityOfElementLocated(locator));
    }

    public WebElement waitForClickable(By locator) {
        return wait.until(
                ExpectedConditions
                        .elementToBeClickable(locator));
    }

    public void click(By locator) {
        try {
            waitForClickable(locator).click();
        } catch (RuntimeException e) {
            throw new AssertionError(
                    "Unable to click: " + locator, e);
        }
    }

    public void validateVisible(
            By locator, String message) {

        Assert.assertTrue(
                waitForVisible(locator).isDisplayed(),
                message);
    }

    public void validateHidden(
            By locator, String message) {

        wait.until(d -> {
            List<WebElement> elements =
                    d.findElements(locator);

            return elements.isEmpty()
                    || elements.stream()
                    .noneMatch(WebElement::isDisplayed);
        });

        Assert.assertTrue(
                driver.findElements(locator).stream()
                        .noneMatch(WebElement::isDisplayed),
                message);
    }

    public void validateClickable(
            By locator, String message) {

        Assert.assertTrue(
                waitForClickable(locator).isEnabled(),
                message);
    }

    public void validateUrlUnchanged(
            String originalUrl, String message) {

        wait.until(d ->
                d.getCurrentUrl().equals(originalUrl));

        Assert.assertEquals(
                driver.getCurrentUrl(),
                originalUrl,
                message);
    }
}
