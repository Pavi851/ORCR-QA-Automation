
package tests;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

/**
 * Desktop video recorder using FFmpeg.
 * Supports Windows, macOS, and Linux.
 *
 * Recordings are finalized when stop() is called.
 * Returns the absolute recording path when successful.
 */
public final class FfmpegScreenRecorder {

    private Process process;
    private Path output;
    private Thread logReader;

    public synchronized void start(Path outputFile) {

        if (process != null && process.isAlive()) {
            stop();
        }

        try {
            output = outputFile.toAbsolutePath()
                    .normalize();

            Path parent = output.getParent();

            if (parent != null) {
                Files.createDirectories(parent);
            }

            String os = System.getProperty(
                    "os.name", ""
            ).toLowerCase(Locale.ROOT);

            ProcessBuilder pb;

            if (os.contains("win")) {

                pb = new ProcessBuilder(
                        "ffmpeg",
                        "-hide_banner",
                        "-loglevel", "warning",
                        "-y",
                        "-f", "gdigrab",
                        "-framerate", "10",
                        "-i", "desktop",
                        "-c:v", "libx264",
                        "-preset", "ultrafast",
                        "-pix_fmt", "yuv420p",
                        "-movflags", "+faststart",
                        output.toString()
                );

            } else if (os.contains("mac")) {

                pb = new ProcessBuilder(
                        "ffmpeg",
                        "-hide_banner",
                        "-loglevel", "warning",
                        "-y",
                        "-f", "avfoundation",
                        "-framerate", "10",
                        "-i", "1:none",
                        "-c:v", "libx264",
                        "-preset", "ultrafast",
                        "-pix_fmt", "yuv420p",
                        "-movflags", "+faststart",
                        output.toString()
                );

            } else {

                String display = System.getenv()
                        .getOrDefault("DISPLAY", ":0.0");

                pb = new ProcessBuilder(
                        "ffmpeg",
                        "-hide_banner",
                        "-loglevel", "warning",
                        "-y",
                        "-f", "x11grab",
                        "-framerate", "10",
                        "-i", display,
                        "-c:v", "libx264",
                        "-preset", "ultrafast",
                        "-pix_fmt", "yuv420p",
                        "-movflags", "+faststart",
                        output.toString()
                );
            }

            // Merge FFmpeg errors and normal output.
            pb.redirectErrorStream(true);

            process = pb.start();

            Process currentProcess = process;

            // Drain FFmpeg output to prevent the process
            // from blocking when its output buffer fills.
            logReader = new Thread(() -> {
                try (BufferedReader reader =
                             new BufferedReader(
                                     new InputStreamReader(
                                             currentProcess
                                                     .getInputStream()))) {

                    String line;

                    while ((line = reader.readLine()) != null) {
                        System.out.println(
                                "[FFmpeg] " + line
                        );
                    }

                } catch (IOException e) {
                    System.err.println(
                            "Unable to read FFmpeg output: "
                                    + e.getMessage()
                    );
                }
            }, "ffmpeg-log-reader");

            logReader.setDaemon(true);
            logReader.start();

            // Give FFmpeg time to initialize.
            Thread.sleep(1000);

            if (!process.isAlive()) {
                int exitCode = process.exitValue();
                process = null;

                throw new IOException(
                        "FFmpeg exited during startup. Exit code: "
                                + exitCode
                                + ". Check the FFmpeg logs above."
                );
            }

            System.out.println(
                    "Recording started: " + output
            );

        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            cleanupProcess();

            throw new IllegalStateException(
                    "Recording startup was interrupted.", e
            );

        } catch (IOException e) {
            cleanupProcess();

            throw new IllegalStateException(
                    "Unable to start screen recording: "
                            + e.getMessage(), e
            );
        }
    }

    public synchronized String stop() {

        if (process == null) {
            return null;
        }

        Process currentProcess = process;
        Path recording = output;

        try {
            // Send q so FFmpeg can finalize the MP4 container.
            try {
                currentProcess.getOutputStream().write(
                        "q\n".getBytes(
                                java.nio.charset.StandardCharsets.UTF_8
                        )
                );
                currentProcess.getOutputStream().flush();

            } catch (IOException e) {
                System.err.println(
                        "Could not send graceful stop to FFmpeg: "
                                + e.getMessage()
                );
            }

            // Allow FFmpeg to write the MP4 index and close the file.
            boolean finished = currentProcess.waitFor(
                    15, TimeUnit.SECONDS
            );

            if (!finished) {
                System.err.println(
                        "FFmpeg did not stop gracefully; terminating it."
                );

                currentProcess.destroy();

                if (!currentProcess.waitFor(
                        3, TimeUnit.SECONDS
                )) {
                    currentProcess.destroyForcibly();
                    currentProcess.waitFor();
                }
            }

            if (logReader != null) {
                logReader.join(2000);
            }

            int exitCode = currentProcess.exitValue();

            process = null;
            logReader = null;

            if (recording != null
                    && Files.isRegularFile(recording)
                    && Files.size(recording) > 0
                    && exitCode == 0) {

                System.out.println(
                        "Recording saved successfully: "
                                + recording
                );

                return recording.toString();
            }

            System.err.println(
                    "Recording was not finalized successfully. "
                            + "Exit code: " + exitCode
                            + ", file: " + recording
            );

            return null;

        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            cleanupProcess();
            return null;

        } catch (IOException e) {
            System.err.println(
                    "Error stopping recording: "
                            + e.getMessage()
            );
            cleanupProcess();
            return null;
        }
    }

    private void cleanupProcess() {

        if (process != null) {
            process.destroyForcibly();
            process = null;
        }

        if (logReader != null) {
            logReader.interrupt();
            logReader = null;
        }
    }
}
 