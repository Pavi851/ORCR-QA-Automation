package tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class BaseTest {
    protected WebDriver driver;
    private FfmpegScreenRecorder recorder;

    protected static final String BASE_URL =
            System.getProperty("base.url", "https://www.testerrank.com/insurance");

    @BeforeMethod(alwaysRun = true)
    public void setUp(ITestResult result, ITestContext context) {
        driver = new ChromeDriver(); // Selenium Manager resolves the matching driver
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        context.setAttribute("driver", driver);
        driver.get(BASE_URL);

        // Best-effort desktop capture. Requires FFmpeg and a supported visible display.
        String reportsDir = System.getProperty("reports.dir", "target/reports");
        String safeName = result.getMethod().getMethodName().replaceAll("[^a-zA-Z0-9._-]", "_");
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss_SSS"));
        Path recordingPath = Paths.get(reportsDir, "recordings", safeName + "_" + timestamp + ".mp4");
        recorder = new FfmpegScreenRecorder();
        recorder.start(recordingPath);
    }

    @AfterMethod(alwaysRun = true)
    public void tearDown(ITestResult result) {
        try {
            // Leave the browser visible for 3 seconds at the end of execution so the final page state
            // can be observed and included in the screen recording before the window closes.
            try { Thread.sleep(3000); }
            catch (InterruptedException e) { Thread.currentThread().interrupt(); }
            if (recorder != null) {
                String videoPath = recorder.stop();
                if (videoPath != null && result != null) {
                    result.getTestContext().setAttribute(
                            "video." + result.getMethod().getMethodName(), videoPath);
                }
            }
        } finally {
            if (driver != null) {
                driver.quit();
            }
        }
    }
}
