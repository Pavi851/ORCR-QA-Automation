# ORCR Policy Validation — POM, screenshots, and recordings

## Stack
- Java 17
- Selenium 4.35.0
- TestNG 7.11.0
- Maven
- ExtentReports HTML report
- Passed/failed/skipped screenshots
- Optional FFmpeg desktop screen recordings

## Page Object Model
- `src/test/java/pages/InsurancePage.java`: locators, waits, and page interactions.
- `src/test/java/tests/BaseTest.java`: WebDriver lifecycle and per-test screen recording.
- `src/test/java/tests/InsuranceTests.java`: test cases and assertions.
- `src/test/java/tests/ExtentReportListener.java`: HTML report and outcome screenshots/video links.
- `testng.xml`: TestNG suite configuration.

## Run
1. Open this folder as a Maven project.
2. Use JDK 17 and have Google Chrome installed.
3. Install FFmpeg and make sure the `ffmpeg` command is available on PATH if you need screen recordings.
4. Run `mvn test` to retain artifacts from previous runs in `target/reports`.
5. Run `mvn clean test` only when you intentionally want to remove previous build artifacts first.

Default URL: `https://www.testerrank.com/insurance`
Override it with: `mvn test -Dbase.url=https://your-test-url`

## Artifacts
- HTML report: `target/reports/InsuranceReport.html`
- Passed screenshots: `target/reports/screenshots/passed/`
- Failed screenshots: `target/reports/screenshots/failed/`
- Skipped screenshots: `target/reports/screenshots/skipped/`
- Recordings: `target/reports/recordings/`

Each screenshot and recording filename includes a timestamp to reduce the chance of overwriting files across test runs. The HTML report includes screenshot attachments and links to recordings when recording succeeds.

## Important retention notes
- Use `mvn test` (not `mvn clean test`) to preserve artifacts from previous runs.
- The default Maven `target` directory is normally excluded from source control and is deleted by `mvn clean`. Copy/archive `target/reports` before cleaning if you need long-term retention.
- FFmpeg recording is best-effort and requires FFmpeg on PATH plus a supported, visible desktop/display. It may not work in headless CI or remote environments without a display. If unavailable, tests still run; screenshots and HTML reporting remain enabled.

## Intentional failures
`InsuranceTests` contains exactly two tests named `intentionalFailure_*`. They deliberately compare actual URL/title against incorrect expected values to demonstrate two assertion failures. These are report-validation tests, not product defects. Remove them or correct their expected values for a normal passing run.
