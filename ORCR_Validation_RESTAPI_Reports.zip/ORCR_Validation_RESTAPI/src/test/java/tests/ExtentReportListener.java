package tests;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class ExtentReportListener implements ITestListener {
    private static ExtentReports extent;
    private static final ThreadLocal<ExtentTest> currentTest = new ThreadLocal<>();
    private static Path reportsDir;

    @Override
    public synchronized void onStart(ITestContext context) {
        String configured = System.getProperty("reports.dir", "target/reports");
        reportsDir = Paths.get(configured).toAbsolutePath();
        try {
            Files.createDirectories(reportsDir.resolve("screenshots/passed"));
            Files.createDirectories(reportsDir.resolve("screenshots/failed"));
            Files.createDirectories(reportsDir.resolve("screenshots/skipped"));
            Files.createDirectories(reportsDir.resolve("recordings"));
            ExtentSparkReporter spark = new ExtentSparkReporter(
                    reportsDir.resolve("InsuranceReport.html").toString());
            spark.config().setDocumentTitle("ORCR Policy Validation - Test Report");
            spark.config().setReportName("Insurance Policy Validation");
            spark.config().setEncoding("UTF-8");
            extent = new ExtentReports();
            extent.attachReporter(spark);
            extent.setSystemInfo("Project", "ORCR Policy Validation");
            extent.setSystemInfo("Browser", "Chrome (Selenium WebDriver)");
            extent.setSystemInfo("Run started",
                    LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
            extent.setSystemInfo("Artifacts directory", reportsDir.toString());
        } catch (Exception e) {
            throw new RuntimeException("Could not initialize HTML report in " + reportsDir, e);
        }
    }

    @Override
    public void onTestStart(ITestResult result) {
        currentTest.set(extent.createTest(result.getMethod().getMethodName()));
        currentTest.get().info("Test started");
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        ExtentTest test = currentTest.get();
        if (test != null) test.pass("Test passed");
        captureScreenshot(result, "passed");
        attachVideoIfPresent(result);
        currentTest.remove();
    }

    @Override
    public void onTestFailure(ITestResult result) {
        ExtentTest test = currentTest.get();
        if (test != null) test.fail(result.getThrowable());
        captureScreenshot(result, "failed");
        attachVideoIfPresent(result);
        currentTest.remove();
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        ExtentTest test = currentTest.get();
        if (test != null) {
            if (result.getThrowable() == null) test.skip("Test skipped");
            else test.skip(result.getThrowable());
        }
        captureScreenshot(result, "skipped");
        attachVideoIfPresent(result);
        currentTest.remove();
    }

    private void captureScreenshot(ITestResult result, String outcome) {
        ExtentTest test = currentTest.get();
        Object value = result.getTestContext().getAttribute("driver");
        if (!(value instanceof WebDriver driver) || !(driver instanceof TakesScreenshot)) {
            if (test != null) test.warning("Screenshot unavailable: WebDriver was not available.");
            return;
        }

        try {
            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss_SSS"));
            String name = safeName(result.getMethod().getMethodName()) + "_" + timestamp + ".png";
            Path screenshot = reportsDir.resolve("screenshots").resolve(outcome).resolve(name);
            Files.createDirectories(screenshot.getParent());
            Files.write(screenshot, ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES));

            if (test != null) {
                String relativePath = "screenshots/" + outcome + "/" + name;
                test.info(outcome.substring(0, 1).toUpperCase() + outcome.substring(1) +
                        " screenshot: " + name,
                        MediaEntityBuilder.createScreenCaptureFromPath(relativePath).build());
            }
        } catch (Exception e) {
            if (test != null) test.warning("Could not save " + outcome + " screenshot: " + e.getMessage());
        }
    }

    private void attachVideoIfPresent(ITestResult result) {
        ExtentTest test = currentTest.get();
        if (test == null) return;
        Object value = result.getTestContext().getAttribute("video." + result.getMethod().getMethodName());
        if (!(value instanceof String video) || !Files.exists(Paths.get(video))) {
            test.info("Screen recording unavailable for this test (FFmpeg/display may not be configured).");
            return;
        }

        try {
            Path videoPath = Paths.get(video).toAbsolutePath();
            Path relative = reportsDir.toAbsolutePath().relativize(videoPath);
            String href = relative.toString().replace('\\', '/');
            test.info("Screen recording: <a href=\"" + href + "\" target=\"_blank\">" +
                    videoPath.getFileName() + "</a>");
        } catch (Exception e) {
            test.warning("Recording saved, but its report link could not be created: " + e.getMessage());
        }
    }

    @Override
    public synchronized void onFinish(ITestContext context) {
        if (extent != null) extent.flush();
    }

    private static String safeName(String name) {
        return name.replaceAll("[^a-zA-Z0-9._-]", "_");
    }
}
