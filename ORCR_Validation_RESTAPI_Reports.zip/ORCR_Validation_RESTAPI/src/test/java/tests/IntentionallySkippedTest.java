package tests;

import org.testng.SkipException;
import org.testng.annotations.Test;

/** Demonstrates a skipped test while keeping the browser open long enough to capture artifacts. */
public class IntentionallySkippedTest extends BaseTest {

    @Test(description = "INTENTIONAL SKIP - demonstrate skipped screenshot and recording")
    public void intentionallySkippedPolicyScenario() throws InterruptedException {
        // The page is already open from BaseTest.setUp(). Keep it visible for review.
        Thread.sleep(3000);
        // ExtentReportListener captures the current browser screenshot into screenshots/skipped.
        throw new SkipException("Intentional skip for framework demonstration; not a product defect.");
    }
}
