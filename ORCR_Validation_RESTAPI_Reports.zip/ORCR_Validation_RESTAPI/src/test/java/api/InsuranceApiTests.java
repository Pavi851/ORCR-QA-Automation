package api;

import com.sun.net.httpserver.HttpServer;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;

public class InsuranceApiTests {

    private static final String BASE_URL = "https://jsonplaceholder.typicode.com";

    @Test
    public void getPostById() {
        Response response = given()
                .baseUri(BASE_URL)
                .accept(ContentType.JSON)
                .when()
                .get("/posts/1")
                .then()
                .statusCode(200)
                .contentType(ContentType.JSON)
                .body("id", equalTo(1))
                .body("userId", equalTo(1))
                .body("title", notNullValue())
                .extract().response();

        logResponse("GET", response);
        Assert.assertEquals(response.getStatusCode(), 200);
    }

    @Test
    public void createPost() {
        String requestBody = """
                {
                  "title": "Insurance API Test",
                  "body": "Testing API using Rest Assured",
                  "userId": 1
                }
                """;

        Response response = given()
                .baseUri(BASE_URL)
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .body(requestBody)
                .when()
                .post("/posts")
                .then()
                .statusCode(201)
                .body("title", equalTo("Insurance API Test"))
                .body("userId", equalTo(1))
                .extract().response();

        logResponse("POST", response);
        Assert.assertEquals(response.getStatusCode(), 201);
    }

    @Test
    public void updatePostUsingPut() {
        String requestBody = """
                {
                  "id": 1,
                  "title": "Updated Insurance API Test",
                  "body": "Updated with PUT using Rest Assured",
                  "userId": 1
                }
                """;

        Response response = given()
                .baseUri(BASE_URL)
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .body(requestBody)
                .when()
                .put("/posts/1")
                .then()
                .statusCode(200)
                .body("id", equalTo(1))
                .body("title", equalTo("Updated Insurance API Test"))
                .extract().response();

        logResponse("PUT", response);
        Assert.assertEquals(response.getStatusCode(), 200);
    }

    @Test
    public void deletePost() {
        Response response = given()
                .baseUri(BASE_URL)
                .accept(ContentType.JSON)
                .when()
                .delete("/posts/1")
                .then()
                .statusCode(200)
                .extract().response();

        logResponse("DELETE", response);
        Assert.assertEquals(response.getStatusCode(), 200);
    }

    /**
     * JSONPlaceholder is a demo API and does not reliably produce server errors.
     * This local stub returns HTTP 500 so the error-response assertion is deterministic.
     */
    @Test
    public void handlesInternalServerError500() throws IOException {
        HttpServer server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        server.createContext("/simulate-500", exchange -> {
            byte[] body = "{\"error\":\"Internal Server Error\"}"
                    .getBytes(StandardCharsets.UTF_8);
            exchange.getResponseHeaders().set("Content-Type", "application/json");
            exchange.sendResponseHeaders(500, body.length);
            exchange.getResponseBody().write(body);
            exchange.close();
        });
        server.start();

        try {
            int port = server.getAddress().getPort();
            Response response = given()
                    .baseUri("http://127.0.0.1:" + port)
                    .accept(ContentType.JSON)
                    .when()
                    .get("/simulate-500")
                    .then()
                    .statusCode(500)
                    .body("error", equalTo("Internal Server Error"))
                    .extract().response();

            logResponse("GET (simulated 500)", response);
            Assert.assertEquals(response.getStatusCode(), 500);
        } finally {
            server.stop(0);
        }
    }

    private void logResponse(String method, Response response) {
        System.out.println(method + " API - Status Code: " + response.getStatusCode());
        System.out.println(method + " API - Response Body:");
        response.prettyPrint();
    }
}
