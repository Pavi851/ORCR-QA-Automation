package hooks;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import pages.InsurancePage;
import tests.FfmpegScreenRecorder;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class ScenarioHooks {
    private static final ThreadLocal<WebDriver> DRIVER = new ThreadLocal<>();
    private static final ThreadLocal<InsurancePage> PAGE = new ThreadLocal<>();
    private static final ThreadLocal<FfmpegScreenRecorder> RECORDER = new ThreadLocal<>();
    private static final ThreadLocal<Path> VIDEO = new ThreadLocal<>();

    public static WebDriver driver() { return DRIVER.get(); }
    public static InsurancePage page() { return PAGE.get(); }

    @Before
    public void setUp(Scenario scenario) {
        WebDriver driver = new ChromeDriver();
        DRIVER.set(driver);
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        PAGE.set(new InsurancePage(driver));
        driver.get(System.getProperty("base.url", "https://www.testerrank.com/insurance"));

        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss_SSS"));
        String safeName = scenario.getName().replaceAll("[^a-zA-Z0-9._-]", "_");
        Path video = Paths.get(System.getProperty("reports.dir", "target/reports"),
                "recordings", safeName + "_" + timestamp + ".mp4");
        VIDEO.set(video);
        FfmpegScreenRecorder recorder = new FfmpegScreenRecorder();
        RECORDER.set(recorder);
        try {
            recorder.start(video);
        } catch (RuntimeException ex) {
            // Recording is best-effort; do not prevent browser tests from running if
            // FFmpeg or a supported desktop display is unavailable.
            System.err.println("Screen recording unavailable: " + ex.getMessage());
            RECORDER.remove();
        }
    }

    @After
    public void tearDown(Scenario scenario) {
        WebDriver driver = DRIVER.get();
        try {
            // Keep the final browser state visible for 3 seconds before taking the final screenshot
            // and stopping the recording. The window is closed in finally below.
            try { Thread.sleep(3000); }
            catch (InterruptedException e) { Thread.currentThread().interrupt(); }
            if (driver != null && driver instanceof TakesScreenshot) {
                String status = scenario.getStatus().name();
                String outcome = scenario.isFailed() ? "failed"
                        : (status.equals("SKIPPED") || status.equals("PENDING") || status.equals("UNDEFINED")
                        ? "skipped" : "passed");
                String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss_SSS"));
                String safeName = scenario.getName().replaceAll("[^a-zA-Z0-9._-]", "_");
                Path screenshot = Paths.get(System.getProperty("reports.dir", "target/reports"),
                        "screenshots", outcome, safeName + "_" + timestamp + ".png");
                try {
                    Files.createDirectories(screenshot.getParent());
                    Files.write(screenshot, ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES));
                    scenario.attach(Files.readAllBytes(screenshot), "image/png", outcome + " screenshot");
                    System.out.println("Screenshot saved: " + screenshot.toAbsolutePath());
                } catch (Exception e) {
                    System.err.println("Could not save screenshot: " + e.getMessage());
                }
            }
            FfmpegScreenRecorder recorder = RECORDER.get();
            if (recorder != null) {
                String saved = recorder.stop();
                if (saved != null) System.out.println("Recording saved: " + saved);
            }
        } finally {
            if (driver != null) driver.quit();
            DRIVER.remove();
            PAGE.remove();
            RECORDER.remove();
            VIDEO.remove();
        }
    }
}
