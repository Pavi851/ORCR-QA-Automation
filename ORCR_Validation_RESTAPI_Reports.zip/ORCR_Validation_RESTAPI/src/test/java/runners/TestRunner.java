package runners;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(
        features = "src/test/resources/features",
        glue = {"stepdefinitions", "hooks"},
        plugin = {"pretty", "html:target/reports/cucumber-report.html",
                  "json:target/reports/cucumber-report.json"},
        monochrome = true
)
public class TestRunner extends AbstractTestNGCucumberTests {
}
