package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

/**
 * Page Object for the ORCR insurance page.
 * Locators and page interactions belong here; test assertions belong in tests.
 */
public class InsurancePage {
    private final WebDriver driver;
    private final WebDriverWait wait;

    private final By explorePlanButton = By.id("explorePlanBtn");
    private final By explorerCategory = By.id("explorerCategory");
    private final By buyNewPolicyLink = By.id("linkBuyPolicy");

    public InsurancePage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public String getCurrentUrl() {
        return driver.getCurrentUrl();
    }

    public String getPageTitle() {
        return driver.getTitle();
    }

    public boolean isViewPlanButtonEnabled() {
        return wait.until(ExpectedConditions.presenceOfElementLocated(explorePlanButton))
                   .isEnabled();
    }

    public boolean hasCategoryOption(String expectedOption) {
        WebElement dropdown = wait.until(
                ExpectedConditions.visibilityOfElementLocated(explorerCategory));
        Select select = new Select(dropdown);
        return select.getOptions().stream()
                .map(WebElement::getText)
                .anyMatch(expectedOption::equals);
    }

    public void selectCategory(String categoryName) {
        WebElement dropdown = wait.until(
                ExpectedConditions.visibilityOfElementLocated(explorerCategory));
        new Select(dropdown).selectByVisibleText(categoryName);
    }

    public String getSelectedCategory() {
        WebElement dropdown = wait.until(
                ExpectedConditions.visibilityOfElementLocated(explorerCategory));
        return new Select(dropdown).getFirstSelectedOption().getText();
    }

    public boolean isBuyNewPolicyLinkDisplayed() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(buyNewPolicyLink))
                   .isDisplayed();
    }

    /** Returns true if at least one element matching the locator is visible. */
    public boolean isElementVisible(By locator) {
        List<WebElement> elements = driver.findElements(locator);
        return elements.stream().anyMatch(WebElement::isDisplayed);
    }
}
