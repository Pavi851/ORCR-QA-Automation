# ORCR Policy Validation — TestNG + Cucumber BDD + POM

## Framework layout
- `src/test/resources/features/policy_validation.feature`: business-readable Gherkin scenarios.
- `src/test/java/stepdefinitions/PolicyStepDefinitions.java`: Cucumber step definitions.
- `src/test/java/pages/InsurancePage.java`: Page Object Model locators and page actions.
- `src/test/java/hooks/ScenarioHooks.java`: browser lifecycle, passed/failed screenshots, and best-effort screen recordings.
- `src/test/java/runners/TestRunner.java`: Cucumber TestNG runner.
- `src/test/java/tests/InsuranceTests.java`: existing TestNG tests retained.
- `src/test/java/tests/FfmpegScreenRecorder.java`: existing FFmpeg desktop recorder.
- `testng.xml`: runs both the original TestNG tests and the new Cucumber scenarios.

## Run
From the project directory:
```bash
mvn clean test
```
Optional URL override:
```bash
mvn clean test -Dbase.url=https://www.testerrank.com/insurance
```

Artifacts are written under `target/reports/`:
- `screenshots/passed/`
- `screenshots/failed/`
- `recordings/`
- `cucumber-report.html`
- `cucumber-report.json`
- `InsuranceReport.html` (existing TestNG Extent report)

## Recording note
Screen recording requires FFmpeg installed and available on `PATH`, plus a visible desktop/display that FFmpeg can capture. Recording is best-effort and will not intentionally fail the browser test if capture cannot start. In headless/remote environments, screenshots can still be produced while desktop recording may not be available.

## Intentional failures
The two scenarios tagged `@intentional-failure` deliberately assert an incorrect URL/title. They are expected to fail and demonstrate failed screenshots/recordings. Remove the tag's scenarios or correct their expected values for an all-passing run.

## @Override note
`@Override` is optional when Java can infer the overriding method, but it is recommended and retained on interface/ superclass implementations because it catches signature mistakes at compile time. It is not used on methods that do not override a parent method.


## Intentional skipped test and final-page wait
- `tests.IntentionallySkippedTest` is included in `testng.xml` and deliberately throws TestNG `SkipException` after opening the policy page and waiting 3 seconds. This creates a real skipped result for demonstration.
- `ExtentReportListener` saves the skipped screenshot to `target/reports/screenshots/skipped/`.
- TestNG and Cucumber browser sessions remain open for an additional 3 seconds at teardown so the final page state remains visible and is captured in the recording before the browser closes.
- Screen recording remains best-effort and requires FFmpeg plus a supported visible desktop.
