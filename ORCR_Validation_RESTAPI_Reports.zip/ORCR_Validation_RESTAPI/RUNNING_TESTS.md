# Running the ORCR validation project and viewing reports

## Run all reports together

1. Open this folder as a Maven project in IntelliJ (the folder containing `pom.xml`).
2. Use JDK 17 and make sure Google Chrome is installed.
3. Open the IntelliJ Terminal at the project root.
4. Run:

```bash
mvn clean test
```

The `testng.xml` suite runs the Selenium UI tests, skipped-test demonstration, Rest Assured API tests, and Cucumber BDD scenarios. Cucumber scenarios repeat some UI coverage, so those scenarios will run in addition to the standalone UI tests.

## Report locations

After Maven finishes, look under `target/reports/`:

- `InsuranceReport.html` — ExtentReports HTML report for TestNG tests.
- `cucumber-report.html` — Cucumber HTML report.
- `cucumber-report.json` — Cucumber JSON output.
- `screenshots/passed/`, `screenshots/failed/`, and `screenshots/skipped/` — screenshots when a WebDriver is available.
- `recordings/` — optional screen recordings if FFmpeg and a supported desktop/display are available.

On Windows PowerShell, open the report folder with:

```powershell
explorer target/reports
```

Or open a specific HTML report:

```powershell
start target/reports/InsuranceReport.html
start target/reports/cucumber-report.html
```

## Important notes

- `mvn clean test` removes old files under `target` before starting. Use `mvn test` to rerun without deliberately cleaning old build artifacts first.
- The project includes two intentionally failing tests (`intentionalFailure_*`) for demonstrating failed results in reports. Those failures are expected until the tests are removed or corrected.
- A Cucumber report is written only when the Cucumber runner executes. Check the Maven console if compilation or test execution stops early.
- FFmpeg recordings are best-effort and are not required for either HTML report.
