package com.orcr.insurance.tests;

import com.orcr.insurance.db.DatabaseUtil;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.net.http.HttpResponse;
import java.util.UUID;

public class InsuranceApiE2ETests extends BaseApiTest {

    @Test(description = "POST -> DB -> GET -> PUT -> DB -> DELETE -> DB end-to-end chain")
    public void policyCrudApiToDatabaseE2E() throws Exception {

        String number =
                "AUTO-" + UUID.randomUUID()
                        .toString()
                        .substring(0, 8)
                        .toUpperCase();

        HttpResponse<String> post =
                request("POST",
                        "/policies",
                        auth(),
                        policyBody(number, "A101", 12345));

        Assert.assertEquals(
                post.statusCode(),
                201,
                "Expected HTTP 201 but got HTTP "
                        + post.statusCode()
                        + " for POST /policies. Response: "
                        + post.body());

        long id = idFrom(post.body());

        Assert.assertEquals(
                DatabaseUtil.countPolicyById(id),
                1,
                "POST response must be persisted in PostgreSQL");

        Assert.assertEquals(
                DatabaseUtil.policyNumberById(id),
                number,
                "Policy number mismatch in database");

        HttpResponse<String> get =
                request("GET",
                        "/policies/" + id,
                        auth(),
                        null);

        Assert.assertEquals(
                get.statusCode(),
                200,
                "Expected HTTP 200 but got HTTP "
                        + get.statusCode()
                        + " for GET /policies/" + id);

        Assert.assertTrue(
                get.body().contains(number),
                "GET response does not contain policy number " + number);

        String updated =
                "{\"policyNumber\":\"" + number + "\"," +
                        "\"applicantId\":\"A101\"," +
                        "\"agentId\":\"AGTEST\"," +
                        "\"policyType\":\"HEALTH\"," +
                        "\"status\":\"ACTIVE\"," +
                        "\"premium\":13999.50}";

        HttpResponse<String> put =
                request("PUT",
                        "/policies/" + id,
                        auth(),
                        updated);

        Assert.assertEquals(
                put.statusCode(),
                200,
                "Expected HTTP 200 but got HTTP "
                        + put.statusCode()
                        + " for PUT /policies/" + id);

        Assert.assertEquals(
                DatabaseUtil.premiumById(id),
                13999.50,
                0.001,
                "PUT must update database premium");

        HttpResponse<String> delete =
                request("DELETE",
                        "/policies/" + id,
                        auth(),
                        null);

        Assert.assertEquals(
                delete.statusCode(),
                200,
                "Expected HTTP 200 but got HTTP "
                        + delete.statusCode()
                        + " for DELETE /policies/" + id);

        Assert.assertEquals(
                DatabaseUtil.countPolicyById(id),
                0,
                "DELETE must remove database row");

        HttpResponse<String> afterDelete =
                request("GET",
                        "/policies/" + id,
                        auth(),
                        null);

        Assert.assertEquals(
                afterDelete.statusCode(),
                404,
                "Expected HTTP 404 but got HTTP "
                        + afterDelete.statusCode()
                        + " for GET /policies/" + id);
    }

    @Test(description = "Missing token must return 401")
    public void missingTokenReturns401() throws Exception {

        String n =
                "AUTH-" +
                        UUID.randomUUID().toString().substring(0, 8);

        HttpResponse<String> response =
                request("POST",
                        "/policies",
                        null,
                        policyBody(n, "A101", 1000));

        Assert.assertEquals(
                response.statusCode(),
                401,
                "Expected HTTP 401 but got HTTP "
                        + response.statusCode()
                        + " for POST /policies");
    }

    @Test(description = "Invalid token must return 403")
    public void invalidTokenReturns403() throws Exception {

        String n =
                "AUTH-" +
                        UUID.randomUUID().toString().substring(0, 8);

        HttpResponse<String> response =
                request("POST",
                        "/policies",
                        "Bearer invalid-token",
                        policyBody(n, "A101", 1000));

        Assert.assertEquals(
                response.statusCode(),
                403,
                "Expected HTTP 403 but got HTTP "
                        + response.statusCode()
                        + " for POST /policies");
    }

    @Test(description = "Missing required field returns 400")
    public void invalidPayloadReturns400() throws Exception {

        HttpResponse<String> response =
                request("POST",
                        "/policies",
                        auth(),
                        "{\"policyNumber\":\"BAD\"}");

        Assert.assertEquals(
                response.statusCode(),
                400,
                "Expected HTTP 400 but got HTTP "
                        + response.statusCode()
                        + " for POST /policies");
    }

    @Test(description = "Non-positive premium returns 400")
    public void invalidPremiumReturns400() throws Exception {

        String n =
                "PREM-" +
                        UUID.randomUUID().toString().substring(0, 8);

        HttpResponse<String> response =
                request("POST",
                        "/policies",
                        auth(),
                        policyBody(n, "A101", 0));

        Assert.assertEquals(
                response.statusCode(),
                400,
                "Expected HTTP 400 but got HTTP "
                        + response.statusCode()
                        + " for POST /policies");
    }

    @Test(description = "Unknown policy id returns 404")
    public void unknownPolicyReturns404() throws Exception {

        HttpResponse<String> response =
                request("GET",
                        "/policies/999999999",
                        auth(),
                        null);

        Assert.assertEquals(
                response.statusCode(),
                404,
                "Expected HTTP 404 but got HTTP "
                        + response.statusCode()
                        + " for GET /policies/999999999");
    }

    @Test(description = "Duplicate policy number returns 409")
    public void duplicatePolicyReturns409() throws Exception {

        String n =
                "DUP-" +
                        UUID.randomUUID().toString().substring(0, 8);

        HttpResponse<String> first =
                request("POST",
                        "/policies",
                        auth(),
                        policyBody(n, "A101", 1000));

        Assert.assertEquals(
                first.statusCode(),
                201,
                "Expected HTTP 201 but got HTTP "
                        + first.statusCode()
                        + " for POST /policies");

        HttpResponse<String> second =
                request("POST",
                        "/policies",
                        auth(),
                        policyBody(n, "A101", 1000));

        Assert.assertEquals(
                second.statusCode(),
                409,
                "Expected HTTP 409 but got HTTP "
                        + second.statusCode()
                        + " for POST /policies");

        long id = idFrom(first.body());

        request("DELETE",
                "/policies/" + id,
                auth(),
                null);
    }

    @Test(description = "Unknown endpoint returns 404")
    public void unknownEndpointReturns404() throws Exception {

        HttpResponse<String> response =
                request("GET",
                        "/not-a-real-endpoint",
                        auth(),
                        null);

        Assert.assertEquals(
                response.statusCode(),
                404,
                "Expected HTTP 404 but got HTTP "
                        + response.statusCode()
                        + " for GET /not-a-real-endpoint");
    }

}