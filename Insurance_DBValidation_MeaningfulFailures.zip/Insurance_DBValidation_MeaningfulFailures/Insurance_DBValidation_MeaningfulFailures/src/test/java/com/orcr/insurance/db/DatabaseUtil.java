
package com.orcr.insurance.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.UUID;

public final class DatabaseUtil {

    private DatabaseUtil() {
        // Utility class
    }

    private static String setting(
            String property,
            String environmentVariable,
            String fallback) {

        String value = System.getProperty(property);

        if (value == null || value.isBlank()) {
            value = System.getenv(environmentVariable);
        }

        if (value == null || value.isBlank()) {
            return fallback;
        }

        return value;
    }

    /**
     * Creates a database connection.
     */
    public static Connection connect() throws SQLException {

        String url = setting(
                "db.url",
                "DB_URL",
                "jdbc:postgresql://localhost:5432/insurance_validation_db"
        );

        String user = setting(
                "db.user",
                "DB_USER",
                "postgres"
        );

        String password = setting(
                "db.password",
                "DB_PASSWORD",
                ""
        );


        if (password.isBlank()) {
            throw new IllegalStateException(
                    "DATABASE CONFIGURATION ERROR: "
                            + "Set DB_PASSWORD environment variable "
                            + "or db.password system property."
            );
        }

        try {
            return DriverManager.getConnection(url, user, password);

        } catch (SQLException e) {
            throw new SQLException(
                    "DATABASE CONNECTION FAILED: "
                            + "Unable to connect to PostgreSQL. "
                            + "SQLState=" + e.getSQLState()
                            + "; ErrorCode=" + e.getErrorCode()
                            + "; Message=" + e.getMessage(),
                    e.getSQLState(),
                    e.getErrorCode(),
                    e
            );
        }
    }

    /**
     * Executes a COUNT query.
     */
    public static int count(String sql) throws SQLException {

        if (sql == null || sql.isBlank()) {
            throw new IllegalArgumentException(
                    "DATABASE COUNT ERROR: SQL query is empty."
            );
        }

        try (
                Connection connection = connect();
                Statement statement = connection.createStatement();
                ResultSet resultSet = statement.executeQuery(sql)
        ) {
            if (!resultSet.next()) {
                throw new SQLException(
                        "DATABASE COUNT ERROR: "
                                + "Query returned no rows."
                );
            }

            return resultSet.getInt(1);

        } catch (SQLException e) {
            throw new SQLException(
                    "DATABASE COUNT FAILED: "
                            + "SQLState=" + e.getSQLState()
                            + "; Message=" + e.getMessage()
                            + "; Query=" + sql,
                    e.getSQLState(),
                    e.getErrorCode(),
                    e
            );
        }
    }

    /**
     * Records test execution history.
     * This is best-effort logging and does not replace test assertions.
     */
    public static void record(
            String runId,
            String testName,
            String outcome,
            String details) {

        String sql =
                "INSERT INTO validation_run_history "
                        + "(run_id, test_name, outcome, details) "
                        + "VALUES (?, ?, ?, ?)";

        try (
                Connection connection = connect();
                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {
            statement.setString(1, runId);
            statement.setString(2, testName);
            statement.setString(3, outcome);
            statement.setString(4, details);

            statement.executeUpdate();

        } catch (SQLException e) {
            System.err.println(
                    "TEST HISTORY RECORDING FAILED: "
                            + e.getMessage()
            );
        }
    }

    public static String newRunId() {
        return UUID.randomUUID().toString();
    }

    /**
     * Inserts a test policy and returns its generated ID.
     */
    public static long createTestPolicy(
            String policyNumber,
            String applicantId,
            double premium) throws SQLException {

        String sql =
                "INSERT INTO policies "
                        + "(policy_number, applicant_id, agent_id, "
                        + "policy_type, status, premium) "
                        + "VALUES (?, ?, 'AGTEST', 'HEALTH', 'ACTIVE', ?) "
                        + "RETURNING policy_id";

        try (
                Connection connection = connect();
                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {
            statement.setString(1, policyNumber);
            statement.setString(2, applicantId);
            statement.setDouble(3, premium);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (!resultSet.next()) {
                    throw new SQLException(
                            "POLICY INSERT FAILED: "
                                    + "No generated policy ID returned."
                    );
                }

                return resultSet.getLong(1);
            }
        }
    }

    public static int countPolicyById(long id)
            throws SQLException {

        String sql =
                "SELECT COUNT(*) FROM policies WHERE policy_id = ?";

        try (
                Connection connection = connect();
                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {
            statement.setLong(1, id);

            try (ResultSet resultSet = statement.executeQuery()) {
                resultSet.next();
                return resultSet.getInt(1);
            }
        }
    }

    public static String policyNumberById(long id)
            throws SQLException {

        String sql =
                "SELECT policy_number FROM policies WHERE policy_id = ?";

        try (
                Connection connection = connect();
                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {
            statement.setLong(1, id);

            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next()
                        ? resultSet.getString("policy_number")
                        : null;
            }
        }
    }

    public static double premiumById(long id)
            throws SQLException {

        String sql =
                "SELECT premium FROM policies WHERE policy_id = ?";

        try (
                Connection connection = connect();
                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {
            statement.setLong(1, id);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (!resultSet.next()) {
                    throw new SQLException(
                            "DATABASE VALIDATION FAILED: "
                                    + "Policy ID " + id + " was not found."
                    );
                }

                return resultSet.getDouble("premium");
            }
        }
    }

    public static void deletePolicyByNumber(String number)
            throws SQLException {

        String sql =
                "DELETE FROM policies WHERE policy_number = ?";

        try (
                Connection connection = connect();
                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {
            statement.setString(1, number);
            statement.executeUpdate();
        }
    }
}
 