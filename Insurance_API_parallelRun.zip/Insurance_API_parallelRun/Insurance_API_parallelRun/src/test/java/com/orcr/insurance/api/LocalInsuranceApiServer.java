package com.orcr.insurance.api;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import com.orcr.insurance.db.DatabaseUtil;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.sql.*;
import java.util.concurrent.Executors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Self-contained demo API backed by the insurance_validation_db PostgreSQL schema. */
public final class LocalInsuranceApiServer {
    private static final Logger log=LoggerFactory.getLogger(LocalInsuranceApiServer.class);
    private static final ObjectMapper JSON=new ObjectMapper();
    private static HttpServer server;
    private static int port;
    private LocalInsuranceApiServer(){}
    public static synchronized void start() throws IOException {
        if(server!=null)return;
        server=HttpServer.create(new InetSocketAddress("127.0.0.1",0),0); port=server.getAddress().getPort();
        server.createContext("/", LocalInsuranceApiServer::handle); server.setExecutor(Executors.newCachedThreadPool()); server.start();
        log.info("Local insurance API started on port {}",port);
    }
    public static String baseUrl(){return "http://127.0.0.1:"+port;}
    public static synchronized void stop(){if(server!=null){server.stop(0);server=null;}}
    private static void handle(HttpExchange x) throws IOException {
        String method=x.getRequestMethod(); String path=x.getRequestURI().getPath();
        String body=new String(x.getRequestBody().readAllBytes(),StandardCharsets.UTF_8);
        log.info("REQUEST {} {} body={}",method,path,body);
        try {
            if(path.equals("/health")){send(x,200,"{\"status\":\"UP\"}");return;}
            String auth=x.getRequestHeaders().getFirst("Authorization");
            if(auth==null||auth.isBlank()){send(x,401,"{\"error\":\"Missing bearer token\"}");return;}
            if(!auth.equals("Bearer valid-token")){send(x,403,"{\"error\":\"Invalid bearer token\"}");return;}
            if(path.equals("/policies") && method.equals("POST")){create(x,body);return;}
            if(path.matches("/policies/[0-9]+")){
                long id=Long.parseLong(path.substring(path.lastIndexOf('/')+1));
                switch(method){case "GET" -> get(x,id); case "PUT" -> update(x,id,body); case "DELETE" -> delete(x,id); default -> send(x,405,"{\"error\":\"Method not allowed\"}");}
                return;
            }
            send(x,404,"{\"error\":\"Endpoint not found\"}");
        } catch(IllegalArgumentException e){send(x,400,jsonError(e.getMessage()));}
          catch(SQLException e){String state=e.getSQLState(); int code=("23505".equals(state))?409:(state!=null&&state.startsWith("23"))?400:500; log.error("Database error SQLState={}: {}",state,e.getMessage());send(x,code,jsonError(code==409?"Duplicate policy number":code==400?"Database constraint rejected request":"Database error"));}
          catch(Exception e){log.error("API error",e);send(x,500,jsonError("Internal server error"));}
    }
    private static void create(HttpExchange x,String body)throws Exception{
        JsonNode n=parse(body); String number=requiredText(n,"policyNumber"), applicant=requiredText(n,"applicantId"), agent=requiredText(n,"agentId"), type=requiredText(n,"policyType"), status=requiredText(n,"status"); double premium=requiredPremium(n);
        if(!status.equals("ACTIVE")&&!status.equals("PENDING")&&!status.equals("CANCELLED"))throw new IllegalArgumentException("status must be ACTIVE, PENDING, or CANCELLED");
        String sql="INSERT INTO policies(policy_number,applicant_id,agent_id,policy_type,status,premium) VALUES(?,?,?,?,?,?) RETURNING policy_id";
        try(Connection c=DatabaseUtil.connect();PreparedStatement ps=c.prepareStatement(sql)){ps.setString(1,number);ps.setString(2,applicant);ps.setString(3,agent);ps.setString(4,type);ps.setString(5,status);ps.setDouble(6,premium);try(ResultSet rs=ps.executeQuery()){rs.next();send(x,201,policyJson(rs.getLong(1),number,applicant,agent,type,status,premium));}}
    }
    private static void get(HttpExchange x,long id)throws Exception{
        String sql="SELECT policy_id,policy_number,applicant_id,agent_id,policy_type,status,premium FROM policies WHERE policy_id=?";
        try(Connection c=DatabaseUtil.connect();PreparedStatement ps=c.prepareStatement(sql)){ps.setLong(1,id);try(ResultSet r=ps.executeQuery()){if(!r.next()){send(x,404,"{\"error\":\"Policy not found\"}");return;}send(x,200,policyJson(r.getLong(1),r.getString(2),r.getString(3),r.getString(4),r.getString(5),r.getString(6),r.getDouble(7)));}}
    }
    private static void update(HttpExchange x,long id,String body)throws Exception{
        JsonNode n=parse(body); String number=requiredText(n,"policyNumber"), applicant=requiredText(n,"applicantId"), agent=requiredText(n,"agentId"), type=requiredText(n,"policyType"), status=requiredText(n,"status");double premium=requiredPremium(n);
        String sql="UPDATE policies SET policy_number=?,applicant_id=?,agent_id=?,policy_type=?,status=?,premium=?,updated_at=CURRENT_TIMESTAMP WHERE policy_id=?";
        try(Connection c=DatabaseUtil.connect();PreparedStatement ps=c.prepareStatement(sql)){ps.setString(1,number);ps.setString(2,applicant);ps.setString(3,agent);ps.setString(4,type);ps.setString(5,status);ps.setDouble(6,premium);ps.setLong(7,id);if(ps.executeUpdate()==0){send(x,404,"{\"error\":\"Policy not found\"}");return;}send(x,200,policyJson(id,number,applicant,agent,type,status,premium));}
    }
    private static void delete(HttpExchange x,long id)throws Exception{
        try(Connection c=DatabaseUtil.connect();PreparedStatement ps=c.prepareStatement("DELETE FROM policies WHERE policy_id=?")){ps.setLong(1,id);if(ps.executeUpdate()==0){send(x,404,"{\"error\":\"Policy not found\"}");return;}send(x,200,"{\"deleted\":true,\"policyId\":"+id+"}");}
    }
    private static JsonNode parse(String body)throws IOException{if(body==null||body.isBlank())throw new IllegalArgumentException("Request body is required");JsonNode n=JSON.readTree(body);if(n==null||!n.isObject())throw new IllegalArgumentException("JSON object required");return n;}
    private static String requiredText(JsonNode n,String field){JsonNode v=n.get(field);if(v==null||v.isNull()||v.asText().isBlank())throw new IllegalArgumentException(field+" is required");return v.asText();}
    private static double requiredPremium(JsonNode n){JsonNode v=n.get("premium");if(v==null||!v.isNumber()||v.asDouble()<=0)throw new IllegalArgumentException("premium must be a number greater than zero");return v.asDouble();}
    private static String policyJson(long id,String no,String applicant,String agent,String type,String status,double premium){return "{\"policyId\":"+id+",\"policyNumber\":"+quote(no)+",\"applicantId\":"+quote(applicant)+",\"agentId\":"+quote(agent)+",\"policyType\":"+quote(type)+",\"status\":"+quote(status)+",\"premium\":"+premium+"}";}
    private static String quote(String s){try{return JSON.writeValueAsString(s);}catch(Exception e){return "\"\"";}}
    private static String jsonError(String s){return "{\"error\":"+quote(s)+"}";}
    private static void send(HttpExchange x,int code,String body)throws IOException{byte[] bytes=body.getBytes(StandardCharsets.UTF_8);x.getResponseHeaders().set("Content-Type","application/json; charset=utf-8");x.getResponseHeaders().set("Cache-Control","no-store");x.sendResponseHeaders(code,bytes.length);x.getResponseBody().write(bytes);x.close();log.info("RESPONSE {} {} body={}",code,x.getRequestURI(),body);}
}
