package com.orcr.insurance.tests;

import com.orcr.insurance.db.DatabaseUtil;
import org.testng.Assert;
import org.testng.annotations.Test;

public class SourceTargetValidationTests extends BaseApiTest {
    @Test(description="Detect known source-to-target quality issues seeded by SQL script") public void detectMissingExtraDuplicateNullAndMismatch() throws Exception {
        ValidationAssertions.assertDbCount("source-to-target reconciliation: missing source policy P1003", "SELECT COUNT(*) FROM source_policies s LEFT JOIN target_policies t ON t.policy_number=s.policy_number WHERE t.target_row_id IS NULL", 1);
        ValidationAssertions.assertDbCount("source-to-target reconciliation: unexpected extra target policy (expected P1006)", "SELECT COUNT(*) FROM target_policies t LEFT JOIN source_policies s ON s.policy_number=t.policy_number WHERE s.source_row_id IS NULL", 1);
        ValidationAssertions.assertDbCount("source-to-target reconciliation: duplicated target policy P1004", "SELECT COUNT(*) FROM (SELECT policy_number FROM target_policies GROUP BY policy_number HAVING COUNT(*)>1) d", 1);
        ValidationAssertions.assertDbCount("source-to-target data quality: expected one NULL target premium for P1005", "SELECT COUNT(*) FROM target_policies WHERE premium IS NULL", 1);
        ValidationAssertions.assertDbCountAtLeast("source-to-target reconciliation: expected premium mismatch for P1002 to be detected", "SELECT COUNT(*) FROM source_policies s JOIN target_policies t ON t.policy_number=s.policy_number WHERE s.premium IS DISTINCT FROM t.premium", 1);
        ValidationAssertions.assertDbCount("source table row count", "SELECT COUNT(*) FROM source_policies", 5);
        ValidationAssertions.assertDbCount("target table row count", "SELECT COUNT(*) FROM target_policies", 6);
    }
    @Test(description="Run history table must be available and store results") public void runHistoryTableExists() throws Exception {
        ValidationAssertions.assertDbCount("validation_run_history table must exist in public schema", "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='public' AND table_name='validation_run_history'", 1);
    }
}
