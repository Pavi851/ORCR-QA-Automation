package com.orcr.insurance.tests;

import com.orcr.insurance.db.DatabaseUtil;
import org.testng.Assert;
import java.sql.SQLException;

/** Assertions that explain the business/data condition that failed. */
public final class ValidationAssertions {
    private ValidationAssertions() {}

    public static void assertDbCount(String description, String sql, long expected) throws SQLException {
        final long actual;
        try {
            actual = DatabaseUtil.count(sql);
        } catch (SQLException e) {
            throw new AssertionError("DATABASE VALIDATION ERROR: " + description
                    + "; SQL query failed. SQLSTATE=" + e.getSQLState()
                    + "; database message=" + e.getMessage(), e);
        }
        Assert.assertEquals(actual, expected,
                "DATABASE VALIDATION FAILED: " + description
                + "; expected count=" + expected + ", actual count=" + actual
                + "; SQL=" + sql);
    }

    public static void assertDbCountAtLeast(String description, String sql, long minimum) throws SQLException {
        final long actual;
        try {
            actual = DatabaseUtil.count(sql);
        } catch (SQLException e) {
            throw new AssertionError("DATABASE VALIDATION ERROR: " + description
                    + "; SQL query failed. SQLSTATE=" + e.getSQLState()
                    + "; database message=" + e.getMessage(), e);
        }
        Assert.assertTrue(actual >= minimum,
                "DATABASE VALIDATION FAILED: " + description
                + "; expected count >= " + minimum + ", actual count=" + actual
                + "; SQL=" + sql);
    }
}
