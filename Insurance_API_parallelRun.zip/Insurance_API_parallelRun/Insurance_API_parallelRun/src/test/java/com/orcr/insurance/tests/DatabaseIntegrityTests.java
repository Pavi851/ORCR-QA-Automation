package com.orcr.insurance.tests;

import com.orcr.insurance.db.DatabaseUtil;
import org.testng.Assert;
import org.testng.annotations.Test;
import java.sql.*;
import java.util.UUID;

public class DatabaseIntegrityTests extends BaseApiTest {
    @Test(description="Validate seeded table counts and relationship joins") public void coreTableCountsAndJoins() throws Exception {
        ValidationAssertions.assertDbCount("applicants seed row count", "SELECT COUNT(*) FROM applicants", 4);
        ValidationAssertions.assertDbCount("policies seed row count", "SELECT COUNT(*) FROM policies", 5);
        ValidationAssertions.assertDbCount("quotes seed row count", "SELECT COUNT(*) FROM quotes", 5);
        ValidationAssertions.assertDbCount("policy/applicant relationship join row count", "SELECT COUNT(*) FROM policies p JOIN applicants a ON a.applicant_id=p.applicant_id LEFT JOIN quotes q ON q.policy_id=p.policy_id", 5);
        ValidationAssertions.assertDbCount("orphan policies referencing missing applicants", "SELECT COUNT(*) FROM policies p LEFT JOIN applicants a ON a.applicant_id=p.applicant_id WHERE a.applicant_id IS NULL", 0);
        ValidationAssertions.assertDbCount("orphan quotes referencing missing policies", "SELECT COUNT(*) FROM quotes q LEFT JOIN policies p ON p.policy_id=q.policy_id WHERE p.policy_id IS NULL", 0);
    }
    @Test(description="Verify primary key, unique, foreign key, not-null and check constraints reject invalid rows") public void constraintsRejectBadData() throws Exception {
        try(Connection c=DatabaseUtil.connect()) {
            Assert.assertThrows(SQLException.class,()->{try(PreparedStatement p=c.prepareStatement("INSERT INTO applicants(applicant_id,applicant_name) VALUES('A101','Duplicate')")){p.executeUpdate();}});
            Assert.assertThrows(SQLException.class,()->{try(PreparedStatement p=c.prepareStatement("INSERT INTO applicants(applicant_id,applicant_name) VALUES(?,NULL)")){p.setString(1,"NULL-"+UUID.randomUUID());p.executeUpdate();}});
            Assert.assertThrows(SQLException.class,()->{try(PreparedStatement p=c.prepareStatement("INSERT INTO policies(policy_number,applicant_id,agent_id,policy_type,status,premium) VALUES('P1001','A101','AG1','HEALTH','ACTIVE',1000)")){p.executeUpdate();}});
            Assert.assertThrows(SQLException.class,()->{try(PreparedStatement p=c.prepareStatement("INSERT INTO policies(policy_number,applicant_id,agent_id,policy_type,status,premium) VALUES(?,?,?,?,?,?)")){p.setString(1,"CONSTRAINT-"+UUID.randomUUID());p.setString(2,"NO-SUCH-APPLICANT");p.setString(3,"AG1");p.setString(4,"HEALTH");p.setString(5,"ACTIVE");p.setDouble(6,1000);p.executeUpdate();}});
            Assert.assertThrows(SQLException.class,()->{try(PreparedStatement p=c.prepareStatement("INSERT INTO policies(policy_number,applicant_id,agent_id,policy_type,status,premium) VALUES(?,?,?,?,?,?)")){p.setString(1,"CONSTRAINT-"+UUID.randomUUID());p.setString(2,"A101");p.setString(3,"AG1");p.setString(4,"HEALTH");p.setString(5,"INVALID");p.setDouble(6,1000);p.executeUpdate();}});
            Assert.assertThrows(SQLException.class,()->{try(PreparedStatement p=c.prepareStatement("INSERT INTO policies(policy_number,applicant_id,agent_id,policy_type,status,premium) VALUES(?,?,?,?,?,?)")){p.setString(1,"CONSTRAINT-"+UUID.randomUUID());p.setString(2,"A101");p.setString(3,"AG1");p.setString(4,"HEALTH");p.setString(5,"ACTIVE");p.setDouble(6,-1);p.executeUpdate();}});
        }
    }
    @Test(description="Policy premium and quote premium should match; no duplicate core policy numbers") public void policyQuoteBusinessChecks() throws Exception {
        ValidationAssertions.assertDbCount("policy premium must match its quote premium", "SELECT COUNT(*) FROM policies p JOIN quotes q ON q.policy_id=p.policy_id WHERE p.premium IS DISTINCT FROM q.quoted_premium", 0);
        ValidationAssertions.assertDbCount("duplicate policy numbers are not allowed", "SELECT COUNT(*) FROM (SELECT policy_number FROM policies GROUP BY policy_number HAVING COUNT(*)>1) d", 0);
        ValidationAssertions.assertDbCount("policy premium must be non-null and greater than zero", "SELECT COUNT(*) FROM policies WHERE premium IS NULL OR premium<=0", 0);
    }
}
