
package com.orcr.insurance.tests;

import com.orcr.insurance.api.LocalInsuranceApiServer;
import com.orcr.insurance.db.DatabaseUtil;
import org.testng.ITestResult;
import org.testng.Assert;
import org.testng.annotations.*;

import java.io.IOException;
import java.net.URI;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class BaseApiTest {

    protected static final Logger log =
            LoggerFactory.getLogger(BaseApiTest.class);

    protected static final HttpClient CLIENT =
            HttpClient.newBuilder()
                    .connectTimeout(Duration.ofSeconds(3))
                    .build();

    protected static String baseUrl;

    protected void logApiCall(
            String method,
            String endpoint,
            HttpResponse<String> response) {

        long threadId = Thread.currentThread().getId();

        System.out.println("\n==================================");
        System.out.println("THREAD ID  : " + threadId);
        System.out.println("METHOD     : " + method);
        System.out.println("ENDPOINT   : " + endpoint);
        System.out.println("STATUS     : " + response.statusCode());
        System.out.println("RESPONSE   : " + response.body());
        System.out.println("==================================\n");
    }

    private final ThreadLocal<String> runId = new ThreadLocal<>();

    @BeforeSuite(alwaysRun = true)
    public void startApi() throws IOException {
        LocalInsuranceApiServer.start();
        baseUrl = LocalInsuranceApiServer.baseUrl();
    }

    @BeforeMethod(alwaysRun = true)
    public void beginRun() {
        runId.set(UUID.randomUUID().toString());
    }

    @AfterMethod(alwaysRun = true)
    public void saveRun(ITestResult result) {

        String outcome =
                result.isSuccess() ? "PASS"
                        : result.getStatus() == ITestResult.SKIP ? "SKIP"
                        : "FAIL";

        Throwable failure = result.getThrowable();

        String details = failure == null
                ? "Test completed: " + outcome
                : failure.getClass().getSimpleName()
                + ": " + failure.getMessage();

        try {
            DatabaseUtil.record(
                    runId.get(),
                    result.getMethod().getQualifiedName(),
                    outcome,
                    details
            );
        } catch (Exception e) {
            // History logging must not hide the actual test result.
            log.error(
                    "TEST HISTORY LOGGING FAILED"
                            + " | Test: {}"
                            + " | Original test outcome: {}"
                            + " | Logging error: {}",
                    result.getMethod().getQualifiedName(),
                    outcome,
                    e.getMessage()
            );
        } finally {
            runId.remove();
        }
    }

    @AfterSuite(alwaysRun = true)
    public void stopApi() {
        LocalInsuranceApiServer.stop();
    }

    protected HttpResponse<String> request(
            String method,
            String path,
            String token,
            String body) throws Exception {

        HttpRequest.Builder builder =
                HttpRequest.newBuilder()
                        .uri(URI.create(baseUrl + path))
                        .timeout(Duration.ofSeconds(5))
                        .header("Content-Type", "application/json")
                        .header("Accept", "application/json");

        if (token != null) {
            builder.header("Authorization", token);
        }

        HttpRequest.BodyPublisher publisher =
                body == null
                        ? HttpRequest.BodyPublishers.noBody()
                        : HttpRequest.BodyPublishers.ofString(
                        body, StandardCharsets.UTF_8);

        builder.method(method, publisher);

        long start = System.nanoTime();

        HttpResponse<String> response = CLIENT.send(
                builder.build(),
                HttpResponse.BodyHandlers.ofString()
        );

        long elapsedMs =
                (System.nanoTime() - start) / 1_000_000;

        log.info(
                "API RESPONSE | Method: {} | Path: {}"
                        + " | Status: {} | Duration: {} ms"
                        + " | Body: {}",
                method,
                path,
                response.statusCode(),
                elapsedMs,
                response.body()
        );

        Assert.assertTrue(
                elapsedMs < 3000,
                "API PERFORMANCE VALIDATION FAILED"
                        + " | Method: " + method
                        + " | Endpoint: " + path
                        + " | Maximum: 3000 ms"
                        + " | Actual: " + elapsedMs + " ms"
        );

        return response;
    }

    protected String auth() {
        return "Bearer valid-token";
    }

    protected String policyBody(
            String number,
            String applicant,
            double premium) {

        return "{\"policyNumber\":\"" + number + "\","
                + "\"applicantId\":\"" + applicant + "\","
                + "\"agentId\":\"AGTEST\","
                + "\"policyType\":\"HEALTH\","
                + "\"status\":\"ACTIVE\","
                + "\"premium\":" + premium + "}";
    }

    protected long idFrom(String json) throws Exception {

        com.fasterxml.jackson.databind.JsonNode node =
                new com.fasterxml.jackson.databind.ObjectMapper()
                        .readTree(json);

        if (node == null
                || node.get("policyId") == null
                || !node.get("policyId").canConvertToLong()) {

            Assert.fail(
                    "API RESPONSE VALIDATION FAILED"
                            + " | Expected a numeric policyId"
                            + " | Actual response: " + json
            );
        }

        return node.get("policyId").asLong();
    }
}
 