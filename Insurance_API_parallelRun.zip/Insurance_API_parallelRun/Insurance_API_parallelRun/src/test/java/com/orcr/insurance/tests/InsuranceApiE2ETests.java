package com.orcr.insurance.tests;

import com.orcr.insurance.db.DatabaseUtil;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.net.http.HttpResponse;
import java.util.UUID;

public class InsuranceApiE2ETests extends BaseApiTest {

    @Test(description = "POST -> DB -> GET -> PUT -> DB -> DELETE -> DB end-to-end chain")
    public void policyCrudApiToDatabaseE2E() throws Exception {

        String number =
                "AUTO-" + UUID.randomUUID()
                        .toString()
                        .substring(0, 8)
                        .toUpperCase();

        HttpResponse<String> post =
                request("POST",
                        "/policies",
                        auth(),
                        policyBody(number, "A101", 12345));

        logApiCall("POST", "/policies", post);
        Assert.assertEquals(post.statusCode(), 201);

        long id = idFrom(post.body());

        Assert.assertEquals(
                DatabaseUtil.countPolicyById(id),
                1,
                "POST response must be persisted in PostgreSQL");

        Assert.assertEquals(
                DatabaseUtil.policyNumberById(id),
                number,
                "Policy number mismatch in database");

        HttpResponse<String> get =
                request("GET",
                        "/policies/" + id,
                        auth(),
                        null);

        logApiCall("GET", "/policies/" + id, get);
        Assert.assertEquals(get.statusCode(), 200);

        Assert.assertTrue(
                get.body().contains(number),
                "GET response does not contain policy number " + number);

        String updated =
                "{\"policyNumber\":\"" + number + "\"," +
                        "\"applicantId\":\"A101\"," +
                        "\"agentId\":\"AGTEST\"," +
                        "\"policyType\":\"HEALTH\"," +
                        "\"status\":\"ACTIVE\"," +
                        "\"premium\":13999.50}";

        HttpResponse<String> put =
                request("PUT",
                        "/policies/" + id,
                        auth(),
                        updated);

        logApiCall("PUT", "/policies/" + id, put);
        Assert.assertEquals(put.statusCode(), 200);

        Assert.assertEquals(
                DatabaseUtil.premiumById(id),
                13999.50,
                0.001,
                "PUT must update database premium");

        HttpResponse<String> delete =
                request("DELETE",
                        "/policies/" + id,
                        auth(),
                        null);

        logApiCall("DELETE", "/policies/" + id, delete);
        Assert.assertEquals(delete.statusCode(), 200);

        Assert.assertEquals(
                DatabaseUtil.countPolicyById(id),
                0,
                "DELETE must remove database row");

        HttpResponse<String> afterDelete =
                request("GET",
                        "/policies/" + id,
                        auth(),
                        null);

        logApiCall("GET", "/policies/" + id, afterDelete);
        Assert.assertEquals(afterDelete.statusCode(), 404);
    }

    @Test(description = "Missing token must return 401")
    public void missingTokenReturns401() throws Exception {

        String n =
                "AUTH-" +
                        UUID.randomUUID().toString().substring(0, 8);

        HttpResponse<String> response =
                request("POST",
                        "/policies",
                        null,
                        policyBody(n, "A101", 1000));

        logApiCall("POST", "/policies", response);
        Assert.assertEquals(response.statusCode(), 401);
    }

    @Test(description = "Invalid token must return 403")
    public void invalidTokenReturns403() throws Exception {

        String n =
                "AUTH-" +
                        UUID.randomUUID().toString().substring(0, 8);

        HttpResponse<String> response =
                request("POST",
                        "/policies",
                        "Bearer invalid-token",
                        policyBody(n, "A101", 1000));

        logApiCall("POST", "/policies", response);
        Assert.assertEquals(response.statusCode(), 403);
    }

    @Test(description = "Missing required field returns 400")
    public void invalidPayloadReturns400() throws Exception {

        HttpResponse<String> response =
                request("POST",
                        "/policies",
                        auth(),
                        "{\"policyNumber\":\"BAD\"}");

        logApiCall("POST", "/policies", response);
        Assert.assertEquals(response.statusCode(), 400);
    }

    @Test(description = "Non-positive premium returns 400")
    public void invalidPremiumReturns400() throws Exception {

        String n =
                "PREM-" +
                        UUID.randomUUID().toString().substring(0, 8);

        HttpResponse<String> response =
                request("POST",
                        "/policies",
                        auth(),
                        policyBody(n, "A101", 0));

        logApiCall("POST", "/policies", response);
        Assert.assertEquals(response.statusCode(), 400);
    }

    @Test(description = "Unknown policy id returns 404")
    public void unknownPolicyReturns404() throws Exception {

        HttpResponse<String> response =
                request("GET",
                        "/policies/999999999",
                        auth(),
                        null);

        logApiCall("GET", "/policies/999999999", response);
        Assert.assertEquals(response.statusCode(), 404);
    }

    @Test(description = "Duplicate policy number returns 409")
    public void duplicatePolicyReturns409() throws Exception {

        String n =
                "DUP-" +
                        UUID.randomUUID().toString().substring(0, 8);

        HttpResponse<String> first =
                request("POST",
                        "/policies",
                        auth(),
                        policyBody(n, "A101", 1000));

        logApiCall("POST", "/policies", first);
        Assert.assertEquals(first.statusCode(), 201);

        HttpResponse<String> second =
                request("POST",
                        "/policies",
                        auth(),
                        policyBody(n, "A101", 1000));

        logApiCall("POST", "/policies", second);
        Assert.assertEquals(second.statusCode(), 409);

        long id = idFrom(first.body());

        request("DELETE",
                "/policies/" + id,
                auth(),
                null);
    }

    @Test(description = "Unknown endpoint returns 404")
    public void unknownEndpointReturns404() throws Exception {

        HttpResponse<String> response =
                request("GET",
                        "/not-a-real-endpoint",
                        auth(),
                        null);

        logApiCall("GET", "/not-a-real-endpoint", response);
        Assert.assertEquals(response.statusCode(), 404);
    }

}