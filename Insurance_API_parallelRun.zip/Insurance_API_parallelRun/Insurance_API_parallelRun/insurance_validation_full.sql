

CREATE TABLE IF NOT EXISTS applicants (
    applicant_id VARCHAR(20) PRIMARY KEY,
    applicant_name VARCHAR(100) NOT NULL,
    email VARCHAR(150) UNIQUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS policies (
    policy_id BIGSERIAL PRIMARY KEY,
    policy_number VARCHAR(30) NOT NULL UNIQUE,
    applicant_id VARCHAR(20) NOT NULL REFERENCES applicants(applicant_id),
    agent_id VARCHAR(20) NOT NULL,
    policy_type VARCHAR(40) NOT NULL,
    status VARCHAR(20) NOT NULL CHECK (status IN ('ACTIVE','PENDING','CANCELLED')),
    premium NUMERIC(12,2) NOT NULL CHECK (premium > 0),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS quotes (
    quote_id BIGSERIAL PRIMARY KEY,
    policy_id BIGINT NOT NULL REFERENCES policies(policy_id) ON DELETE CASCADE,
    quoted_premium NUMERIC(12,2) NOT NULL CHECK (quoted_premium > 0),
    quote_status VARCHAR(20) NOT NULL CHECK (quote_status IN ('CREATED','ACCEPTED','REJECTED')),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Intentionally permissive tables: source/target bad data must be detectable by validation queries.
CREATE TABLE IF NOT EXISTS source_policies (
    source_row_id BIGSERIAL PRIMARY KEY,
    policy_number VARCHAR(30),
    applicant_id VARCHAR(20),
    policy_type VARCHAR(40),
    status VARCHAR(20),
    premium NUMERIC(12,2)
);
CREATE TABLE IF NOT EXISTS target_policies (
    target_row_id BIGSERIAL PRIMARY KEY,
    policy_number VARCHAR(30),
    applicant_id VARCHAR(20),
    policy_type VARCHAR(40),
    status VARCHAR(20),
    premium NUMERIC(12,2)
);

CREATE TABLE IF NOT EXISTS validation_run_history (
    run_id VARCHAR(36) NOT NULL,
    test_name VARCHAR(200) NOT NULL,
    outcome VARCHAR(20) NOT NULL,
    details TEXT,
    executed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_policies_applicant_id ON policies(applicant_id);
CREATE INDEX IF NOT EXISTS idx_quotes_policy_id ON quotes(policy_id);
CREATE INDEX IF NOT EXISTS idx_source_policy_number ON source_policies(policy_number);
CREATE INDEX IF NOT EXISTS idx_target_policy_number ON target_policies(policy_number);

TRUNCATE TABLE quotes, policies, applicants, source_policies, target_policies, validation_run_history RESTART IDENTITY CASCADE;

INSERT INTO applicants(applicant_id, applicant_name, email) VALUES
('A101','Arun Kumar','arun@example.test'),
('A102','Priya S','priya@example.test'),
('A103','Karthik R','karthik@example.test'),
('A104','Meena D','meena@example.test');

INSERT INTO policies(policy_number, applicant_id, agent_id, policy_type, status, premium) VALUES
('P1001','A101','AG01','HEALTH','ACTIVE',12000.00),
('P1002','A102','AG02','LIFE','ACTIVE',15000.00),
('P1003','A103','AG01','HEALTH','PENDING',9000.00),
('P1004','A104','AG03','MOTOR','ACTIVE',7000.00),
('P1005','A101','AG02','LIFE','PENDING',11000.00);

INSERT INTO quotes(policy_id, quoted_premium, quote_status)
SELECT policy_id, premium, 'CREATED' FROM policies ORDER BY policy_id;

INSERT INTO source_policies(policy_number, applicant_id, policy_type, status, premium) VALUES
('P1001','A101','HEALTH','ACTIVE',12000.00),
('P1002','A102','LIFE','ACTIVE',15000.00),
('P1003','A103','HEALTH','PENDING',9000.00),
('P1004','A104','MOTOR','ACTIVE',7000.00),
('P1005','A101','LIFE','PENDING',11000.00);

-- Seed known data-quality defects for the source-to-target tests to detect.
INSERT INTO target_policies(policy_number, applicant_id, policy_type, status, premium) VALUES
('P1001','A101','HEALTH','ACTIVE',12000.00),
('P1002','A102','LIFE','ACTIVE',15500.00), -- premium mismatch
('P1004','A104','MOTOR','ACTIVE',7000.00),
('P1004','A104','MOTOR','ACTIVE',7000.00), -- duplicate
('P1005','A101','LIFE','PENDING',NULL), -- NULL premium
('P1006','A103','HEALTH','ACTIVE',5000.00); -- extra target record

-- 1. Table counts
SELECT 'applicants' AS table_name, COUNT(*) AS row_count FROM applicants
UNION ALL SELECT 'policies', COUNT(*) FROM policies
UNION ALL SELECT 'quotes', COUNT(*) FROM quotes
UNION ALL SELECT 'source_policies', COUNT(*) FROM source_policies
UNION ALL SELECT 'target_policies', COUNT(*) FROM target_policies;

-- 2. Core join: policies + applicants + quotes
SELECT p.policy_number, a.applicant_name, p.policy_type, p.status,
       p.premium AS policy_premium, q.quoted_premium, q.quote_status
FROM policies p
JOIN applicants a ON a.applicant_id = p.applicant_id
LEFT JOIN quotes q ON q.policy_id = p.policy_id
ORDER BY p.policy_number;

-- 3. Applicants with no policy
SELECT a.* FROM applicants a
LEFT JOIN policies p ON p.applicant_id = a.applicant_id
WHERE p.policy_id IS NULL;

-- 4. Orphan checks (expected 0 because FK constraints protect core tables)
SELECT COUNT(*) AS orphan_policies FROM policies p
LEFT JOIN applicants a ON a.applicant_id = p.applicant_id
WHERE a.applicant_id IS NULL;
SELECT COUNT(*) AS orphan_quotes FROM quotes q
LEFT JOIN policies p ON p.policy_id = q.policy_id
WHERE p.policy_id IS NULL;

-- 5. Source -> target missing and extra records
SELECT s.policy_number AS missing_in_target
FROM source_policies s LEFT JOIN target_policies t ON t.policy_number = s.policy_number
WHERE t.target_row_id IS NULL;
SELECT t.policy_number AS extra_in_target
FROM target_policies t LEFT JOIN source_policies s ON s.policy_number = t.policy_number
WHERE s.source_row_id IS NULL;

-- 6. Duplicate target keys
SELECT policy_number, COUNT(*) AS duplicate_count
FROM target_policies GROUP BY policy_number HAVING COUNT(*) > 1;

-- 7. NULL / blank target data
SELECT * FROM target_policies
WHERE policy_number IS NULL OR BTRIM(policy_number) = ''
   OR applicant_id IS NULL OR policy_type IS NULL OR status IS NULL OR premium IS NULL;

-- 8. Field mismatches; one source row may yield multiple target rows if duplicates exist.
SELECT s.policy_number, s.premium AS source_premium, t.premium AS target_premium,
       s.applicant_id AS source_applicant, t.applicant_id AS target_applicant
FROM source_policies s JOIN target_policies t ON t.policy_number = s.policy_number
WHERE s.premium IS DISTINCT FROM t.premium
   OR s.applicant_id IS DISTINCT FROM t.applicant_id
   OR s.policy_type IS DISTINCT FROM t.policy_type
   OR s.status IS DISTINCT FROM t.status;

-- 9. Business validation: policy premium should match each quote (expected 0)
SELECT p.policy_number, p.premium, q.quoted_premium
FROM policies p JOIN quotes q ON q.policy_id = p.policy_id
WHERE p.premium IS DISTINCT FROM q.quoted_premium;

-- 10. Duplicate policy numbers in core table (expected no rows; UNIQUE constraint)
SELECT policy_number, COUNT(*) FROM policies GROUP BY policy_number HAVING COUNT(*) > 1;

-- 11. Constraints inventory
SELECT tc.table_name, tc.constraint_name, tc.constraint_type
FROM information_schema.table_constraints tc
WHERE tc.table_schema = 'public'
  AND tc.table_name IN ('applicants','policies','quotes')
ORDER BY tc.table_name, tc.constraint_type, tc.constraint_name;

-- 12. Latest run history (filled by Java TestNG suite)
SELECT run_id, test_name, outcome, details, executed_at
FROM validation_run_history ORDER BY executed_at DESC LIMIT 50;
