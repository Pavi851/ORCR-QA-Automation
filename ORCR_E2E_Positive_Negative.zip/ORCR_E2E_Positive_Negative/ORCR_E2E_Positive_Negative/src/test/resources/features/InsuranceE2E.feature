Feature: PolicyDekho Insurance Application Testing

  Background:
    Given User opens PolicyDekho portal

  @Positive
  Scenario: Health Insurance Purchase To Logout Flow

    When User purchases a health insurance policy
    Then Policy should be generated successfully

    When User submits a hospitalization claim
    Then Claim should be submitted successfully

    When User uploads a medical document
    Then Document should be uploaded successfully

    When User navigates to dashboard
    And User logs out
    Then User should be logged out successfully


  @Negative
  Scenario: Validate applicant age restriction

    When User purchases a health insurance policy with underage DOB

    Then Age validation message should be displayed


  @Negative
  Scenario: Validate future incident date

    When User purchases a valid health insurance policy

    And User files a claim with future incident date

    Then Future incident date validation should be displayed


  @Negative
  Scenario: Validate claim submission without declaration

    When User purchases a valid health insurance policy

    And User submits claim without accepting declaration

    Then Claim submission should be blocked


  @Ignore
  Scenario: Validate unsupported document upload

    When User uploads unsupported file type

    Then Invalid file upload validation should be displayed


  @Negative
  Scenario: Validate dashboard access after logout

    Given User has logged out successfully

    When User clicks browser back button

    Then Dashboard should not be accessible

    @Negative
    Scenario: Validate claim amount mandatory

      Given User opens PolicyDekho portal

      When User creates a claim without claim amount

      Then Claim amount validation should be displayed