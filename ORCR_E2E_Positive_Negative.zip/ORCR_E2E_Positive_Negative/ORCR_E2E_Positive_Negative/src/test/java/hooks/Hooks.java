package hooks;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import org.openqa.selenium.WebDriver;
import utilities.DriverFactory;
import utilities.ConfigReader;

public class Hooks {

    public static WebDriver driver;

    @Before
    public void setup() {

        driver = DriverFactory.getDriver();

        driver.get(
                ConfigReader.getProperty(
                        "base.url"));
    }

    @After
    public void tearDown() {

        DriverFactory.quitBrowser();
    }
}