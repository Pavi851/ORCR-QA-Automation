package utilities;

import java.io.FileInputStream;
import java.util.Properties;

public class ConfigReader {

    private static Properties properties;

    static {

        try {

            properties = new Properties();

            FileInputStream file =
                    new FileInputStream(
                            "src/test/resources/config.properties");

            properties.load(file);

        } catch (Exception e) {

            throw new RuntimeException(
                    "Unable to load config.properties",
                    e);
        }
    }

    public static String getProperty(String key) {

        return properties.getProperty(key);
    }

    public static int getInt(
            String key,
            int defaultValue) {

        try {

            String value =
                    properties.getProperty(key);

            if (value == null ||
                    value.trim().isEmpty()) {

                return defaultValue;
            }

            return Integer.parseInt(
                    value.trim());

        } catch (Exception e) {

            return defaultValue;
        }
    }

    public static boolean getBoolean(
            String key,
            boolean defaultValue) {

        try {

            String value =
                    properties.getProperty(key);

            if (value == null ||
                    value.trim().isEmpty()) {

                return defaultValue;
            }

            return Boolean.parseBoolean(
                    value.trim());

        } catch (Exception e) {

            return defaultValue;
        }
    }
}