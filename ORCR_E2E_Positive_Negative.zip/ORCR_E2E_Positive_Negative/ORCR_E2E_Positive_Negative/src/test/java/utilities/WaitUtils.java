package utilities;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;

public final class WaitUtils {
    private WaitUtils() {}
    private static WebDriverWait waitFor() {
        return new WebDriverWait(DriverFactory.getDriver(),
                Duration.ofSeconds(ConfigReader.getInt("explicit.wait.seconds", 15)));
    }
    public static WebElement visible(By by) { return waitFor().until(ExpectedConditions.visibilityOfElementLocated(by)); }
    public static WebElement clickable(By by) { return waitFor().until(ExpectedConditions.elementToBeClickable(by)); }
    public static boolean visibleIfPresent(By by) {
        try { return waitFor().until(ExpectedConditions.visibilityOfElementLocated(by)).isDisplayed(); }
        catch (TimeoutException | NoSuchElementException e) { return false; }
    }
}
