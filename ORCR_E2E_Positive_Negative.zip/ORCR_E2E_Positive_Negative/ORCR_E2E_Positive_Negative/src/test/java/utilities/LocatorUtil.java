package utilities;

import org.openqa.selenium.By;

public final class LocatorUtil {
    private LocatorUtil() {}
    public static By by(String configuredLocator) {
        if (configuredLocator == null || configuredLocator.isBlank())
            throw new IllegalArgumentException("A locator is blank. Configure it in config.properties.");
        int separator = configuredLocator.indexOf(':');
        if (separator < 1) throw new IllegalArgumentException("Invalid locator '" + configuredLocator + "'. Use id:value, css:value, name:value or xpath:value.");
        String type = configuredLocator.substring(0, separator).trim().toLowerCase();
        String value = configuredLocator.substring(separator + 1).trim();
        return switch (type) {
            case "id" -> By.id(value);
            case "name" -> By.name(value);
            case "css" -> By.cssSelector(value);
            case "xpath" -> By.xpath(value);
            case "class" -> By.className(value);
            case "tag" -> By.tagName(value);
            case "linktext" -> By.linkText(value);
            case "partiallinktext" -> By.partialLinkText(value);
            default -> throw new IllegalArgumentException("Unsupported locator type: " + type);
        };
    }
}
