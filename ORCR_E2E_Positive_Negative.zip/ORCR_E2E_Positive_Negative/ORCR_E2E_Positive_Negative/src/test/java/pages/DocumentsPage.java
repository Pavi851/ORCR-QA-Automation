package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class DocumentsPage extends BasePage {

    public DocumentsPage(WebDriver driver) {
        super(driver);
    }

    // Navigation

    private final By claimDocumentsTab =
            By.id("claimDocumentsTab");
    private final By documentsTab =
            By.id("navDocuments");

    // Upload Section

    private final By documentUpload =
            By.id("documentUpload");

    private final By documentType =
            By.id("documentType");

    private final By uploadButton =
            By.id("uploadBtn");

    private final By uploadSuccess =
            By.id("uploadSuccess");

    // Documents Table

    private final By documentsTable =
            By.id("documentsTable");

    private final By uploadedDocumentName =
            By.id("docName3");

    private final By uploadedDocumentType =
            By.id("docType3");

    private final By uploadedDocumentStatus =
            By.id("docStatus3");

    /**
     * Navigate to documents page
     */
    public void openDocumentsPage() {

        waitForSeconds(2);

        ((org.openqa.selenium.JavascriptExecutor) driver)
                .executeScript("window.scrollTo(0,0);");

        waitForSeconds(1);

        scrollToElement(documentsTab);

        jsClick(documentsTab);
    }

    /**
     * Upload a document
     */
    public void uploadDocument(String filePath) {

        uploadFile(
                documentUpload,
                filePath);

        selectByVisibleText(
                documentType,
                "Medical Report");

        click(uploadButton);
    }

    /**
     * Verify upload success message
     */
    public boolean verifyUploadSuccess() {

        return isDisplayed(uploadSuccess);
    }

    /**
     * Get success message text
     */
    public String getUploadSuccessMessage() {

        return getText(uploadSuccess);
    }

    /**
     * Verify documents table displayed
     */
    public boolean verifyDocumentsTable() {

        return isDisplayed(documentsTable);
    }

    /**
     * Verify uploaded file exists
     */
    public boolean verifyUploadedDocumentExists() {

        return isDisplayed(uploadedDocumentName);
    }

    /**
     * Get uploaded document name
     */
    public String getUploadedDocumentName() {

        return getText(uploadedDocumentName);
    }

    /**
     * Get uploaded document type
     */
    public String getUploadedDocumentType() {

        return getText(uploadedDocumentType);
    }

    /**
     * Get uploaded document status
     */
    public String getUploadedDocumentStatus() {

        return getText(uploadedDocumentStatus);
    }

    /**
     * Complete document upload flow
     */
    public void uploadMedicalReport(
            String pdfFilePath) {

        openDocumentsPage();

        uploadDocument(pdfFilePath);
    }

    /**
     * Complete verification
     */
    public void verifyUploadedDocument() {

        Assert.assertTrue(
                verifyUploadSuccess(),
                "Upload success message not displayed");

        Assert.assertTrue(
                verifyDocumentsTable(),
                "Documents table not displayed");

        Assert.assertTrue(
                verifyUploadedDocumentExists(),
                "Uploaded document not found in table");
    }

}