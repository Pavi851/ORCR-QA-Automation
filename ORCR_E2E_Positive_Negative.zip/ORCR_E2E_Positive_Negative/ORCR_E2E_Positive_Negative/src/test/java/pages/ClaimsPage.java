package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ClaimsPage extends BasePage {

    public ClaimsPage(WebDriver driver) {
        super(driver);
    }

    // Home Page

    private final By fileClaimBtn =
            By.id("fileClaimBtn");

    // Step 1 - Claim Details

    private final By claimPolicy =
            By.id("claimPolicy");

    private final By incidentDate =
            By.id("incidentDate");

    private final By claimAmount =
            By.id("claimAmount");

    private final By incidentDescription =
            By.id("incidentDescription");

    private final By providerName =
            By.id("providerName");

    private final By claimNextBtn1 =
            By.id("claimNextBtn1");

    // Step 2 - Documents

    private final By docBills =
            By.id("docBills");

    private final By docDischarge =
            By.id("docDischarge");

    private final By docIdProof =
            By.id("docIdProof");

    private final By claimNextBtn2 =
            By.id("claimNextBtn2");

    // Step 3 - Bank Details

    private final By holderName =
            By.id("holderName");

    private final By claimAccountNo =
            By.id("claimAccountNo");

    private final By claimAccountConfirm =
            By.id("claimAccountConfirm");

    private final By claimIfsc =
            By.id("claimIfsc");

    private final By acTypeSavings =
            By.id("acTypeSavings");

    private final By claimNextBtn3 =
            By.id("claimNextBtn3");

    // Step 4 - Submit

    private final By claimDeclaration =
            By.id("claimDeclaration");

    private final By submitClaimBtn =
            By.id("submitClaimBtn");

    // Success

    private final By claimSuccess =
            By.id("claimSuccess");

    private final By claimRefNumber =
            By.id("claimRefNumber");

    private final By claimSuccessClose =
            By.id("claimSuccessClose");

    public void clickFileNewClaim() {

        click(fileClaimBtn);
    }
    private final By claimType =
            By.id("claimType");

    public void fillClaimDetails() {

        selectByVisibleText(
                claimPolicy,
                "POL-H-001 - Health Shield (Active)");

        waitForSeconds(2);

        selectByVisibleText(
                claimType,
                "Hospitalization");

        type(
                incidentDate,
                "16-09-2026");

        type(
                claimAmount,
                "66666");

        type(
                incidentDescription,
                "Heart Attack");

        type(
                providerName,
                "Apollo Hospital");

        scrollToElement(claimNextBtn1);

        waitForSeconds(1);

        jsClick(claimNextBtn1);
    }

    public void uploadClaimDocuments(
            String filePath) {

        uploadFile(
                docBills,
                filePath);

        uploadFile(
                docDischarge,
                filePath);

        uploadFile(
                docIdProof,
                filePath);

        click(claimNextBtn2);
    }

    public void fillBankDetails() {

        type(
                holderName,
                "Rajesh Kumar");

        type(
                claimAccountNo,
                "1234567890");

        type(
                claimAccountConfirm,
                "1234567890");

        type(
                claimIfsc,
                "SBIN0001234");

        click(acTypeSavings);

        click(claimNextBtn3);
    }

    public void submitClaim() {

        scrollToElement(claimDeclaration);

        waitForSeconds(1);

        jsClick(claimDeclaration);

        waitForSeconds(1);

        scrollToElement(submitClaimBtn);

        jsClick(submitClaimBtn);
    }

    public boolean verifyClaimSubmitted() {

        return isDisplayed(claimSuccess);
    }

    public String getClaimReferenceNumber() {

        return getText(claimRefNumber);
    }

    public void closeClaimSuccessPopup() {

        waitForSeconds(2);

        scrollToElement(claimSuccessClose);

        waitForSeconds(1);

        jsClick(claimSuccessClose);
    }
    private final By claimDocumentsTab =
            By.xpath("//*[contains(text(),'Documents')]");

    public void openDocumentsTab() {

        waitForSeconds(2);

        scrollToElement(claimDocumentsTab);

        jsClick(claimDocumentsTab);
    }

    public void createNewClaim(
            String documentPath) {

        clickFileNewClaim();

        fillClaimDetails();

        uploadClaimDocuments(documentPath);

        fillBankDetails();

        submitClaim();
    }

    //Negative
    public void createClaimWithFutureIncidentDate() {

        clickFileNewClaim();

        selectByVisibleText(
                claimPolicy,
                "POL-H-001 - Health Shield (Active)");

        type(
                incidentDate,
                "20-12-2031");

        type(
                claimAmount,
                "10000");

        type(
                incidentDescription,
                "Testing");

        type(
                providerName,
                "Apollo Hospital");

        jsClick(claimNextBtn1);
    }

    public boolean isStillOnClaimStep1() {

        try {

            return driver.findElement(
                            By.id("claimNextBtn1"))
                    .isDisplayed();

        } catch (Exception e) {

            return false;
        }
    }

    //Negative
    public void createClaimWithoutDeclaration() {

        clickFileNewClaim();

        fillClaimDetails();

        uploadClaimDocuments(
                System.getProperty("user.home")
                        + "\\Downloads\\sample.docx");

        fillBankDetails();

        jsClick(submitClaimBtn);
    }

    public void createClaimWithoutAmount() {

        clickFileNewClaim();

        selectByVisibleText(
                claimPolicy,
                "POL-H-001 - Health Shield (Active)");

        type(
                incidentDate,
                "2026-09-15");

        // Intentionally skipped
        // claimAmount

        type(
                incidentDescription,
                "Heart Attack");

        type(
                providerName,
                "Apollo Hospital");

        jsClick(claimNextBtn1);
    }
}