package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class BuyPolicyPage extends BasePage {

    public BuyPolicyPage(WebDriver driver) {
        super(driver);
    }

    // =========================
    // STEP 1
    // =========================

    private final By healthInsurance =
            By.id("policyType_health");

    private final By basicHealthPlan =
            By.id("plan_Basic_Health");

    private final By continueStep1 =
            By.id("continueBtn1");

    // =========================
    // STEP 2
    // =========================

    private final By applicantName =
            By.id("applicantName");

    private final By applicantDob =
            By.id("applicantDob");

    private final By genderMale =
            By.id("gender_male");

    private final By applicantPan =
            By.id("applicantPan");

    private final By applicantAadhaar =
            By.id("applicantAadhaar");

    private final By applicantMobile =
            By.id("applicantMobile");

    private final By applicantEmail =
            By.id("applicantEmail");

    private final By occupation =
            By.id("occupation");

    private final By annualIncome =
            By.id("annualIncome");

    private final By continueStep2 =
            By.id("continueBtn2");

    // =========================
    // STEP 3
    // =========================

    private final By height =
            By.id("height");

    private final By weight =
            By.id("weight");

    private final By noCondition =
            By.id("condNone");

    private final By continueStep3 =
            By.id("continueBtn3");

    // =========================
    // STEP 4
    // =========================

    private final By nomineeName =
            By.id("nomineeName");

    private final By nomineeRelation =
            By.id("nomineeRelation");

    private final By nomineeDob =
            By.id("nomineeDob");

    private final By nomineeAadhaar =
            By.id("nomineeAadhaar");

    private final By nomineeShare =
            By.id("nomineeShare");

    private final By continueStep4 =
            By.id("continueBtn4");

    // =========================
    // STEP 5
    // =========================

    private final By monthlyPayment =
            By.id("paymentMode_monthly");

    private final By upiPayment =
            By.id("paymentMethod_upi");

    private final By upiId =
            By.id("upiId");

    private final By payAndSubmit =
            By.id("paySubmitBtn");

    // =========================
    // STEP 6
    // =========================

    private final By successMessage =
            By.xpath("//h3[contains(text(),'Application Submitted Successfully')]");

    private final By policyNumber =
            By.id("policyNumber");

    private final By applicationReference =
            By.id("applicationRef");

    private final By goToDashboard =
            By.id("goToDashboard");

    // =========================
    // STEP 1
    // =========================

    public void selectHealthInsurancePlan() {

        click(healthInsurance);

        waitForSeconds(1);

        click(basicHealthPlan);

        waitForSeconds(1);

        jsClick(continueStep1);
    }

    // =========================
    // STEP 2
    // =========================

    public void enterPersonalDetails() {

        type(applicantName,
                "Rajesh Kumar");

        // Age 31 (within 18-45 age limit)
        type(applicantDob,
                "15-05-1992");

        click(genderMale);

        type(applicantPan,
                "ABCDE1234F");

        type(applicantAadhaar,
                "123456789012");

        type(applicantMobile,
                "9876543210");

        type(applicantEmail,
                "rajesh@gmail.com");

        selectByVisibleText(
                occupation,
                "Salaried");

        selectByVisibleText(
                annualIncome,
                "5 - 10 Lakh");

        jsClick(continueStep2);
    }

    //step2.1

    public void purchasePolicyWithUnderageDOB() {

        selectHealthInsurancePlan();

        type(applicantName, "Rajesh Kumar");

        type(applicantDob, "20-05-2015");

        click(genderMale);

        type(applicantPan, "ABCDE1234F");

        type(applicantAadhaar, "123456789012");

        type(applicantMobile, "9876543210");

        type(applicantEmail, "rajesh@gmail.com");

        selectByVisibleText(
                occupation,
                "Salaried");

        selectByVisibleText(
                annualIncome,
                "5 - 10 Lakh");

        jsClick(continueStep2);
    }

    // =========================
    // STEP 3
    // =========================

    public void enterHealthDetails() {

        type(height,
                "170");

        type(weight,
                "70");

        click(noCondition);

        jsClick(continueStep3);
    }

    // =========================
    // STEP 4
    // =========================

    public void enterNomineeDetails() {

        type(nomineeName,
                "Priya Kumar");

        selectByVisibleText(
                nomineeRelation,
                "Spouse");

        type(nomineeDob,
                "1992-01-01");

        type(nomineeAadhaar,
                "987654321012");

        type(nomineeShare,
                "100");

        jsClick(continueStep4);
    }

    // =========================
    // STEP 5
    // =========================

    public void makePayment() {

        click(monthlyPayment);

        click(upiPayment);

        type(upiId,
                "testuser@upi");

        jsClick(payAndSubmit);
    }

    // =========================
    // STEP 6
    // =========================

    public boolean verifyPolicyCreated() {

        try {

            return isDisplayed(policyNumber);

        } catch (Exception e) {

            return false;
        }
    }
    public String getPolicyNumber() {

        String policyNo = getText(policyNumber);

        System.out.println("Policy Number = " + policyNo);

        return policyNo;
    }

    public String getApplicationReference() {

        String appRef = getText(applicationReference);

        System.out.println("Application Reference = " + appRef);

        return appRef;
    }

    public void navigateToDashboard() {

        jsClick(goToDashboard);
    }

    // =========================
    // COMPLETE FLOW
    // =========================

    public void purchaseHealthInsurancePolicy() {

        selectHealthInsurancePlan();

        enterPersonalDetails();

        enterHealthDetails();

        enterNomineeDetails();

        makePayment();
    }
}