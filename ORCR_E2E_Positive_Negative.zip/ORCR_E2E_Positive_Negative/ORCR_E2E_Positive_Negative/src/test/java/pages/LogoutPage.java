package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class LogoutPage extends BasePage {

    public LogoutPage(WebDriver driver) {
        super(driver);
    }

    // Dashboard

    private final By dashboardMenu =
            By.id("navDashboard");

    private final By welcomeHeading =
            By.id("welcomeHeading");

    private final By logoutButton =
            By.id("logoutBtn");

    // Logout Landing Page

    private final By loginButton =
            By.id("navLogin");

    private final By registerButton =
            By.id("navRegister");

    private final By heroLogin =
            By.id("heroLogin");

    private final By heroRegister =
            By.id("heroRegister");

    private final By heroSection =
            By.id("heroSection");

    private final By portalTitle =
            By.id("portalTitle");

    /**
     * Navigate to dashboard
     */
    public void navigateToDashboard() {

        click(dashboardMenu);
    }

    /**
     * Logout
     */
    public void logout() {

        click(logoutButton);
    }

    /**
     * Verify login button displayed
     */
    public boolean isLoginButtonDisplayed() {

        return isDisplayed(loginButton);
    }

    /**
     * Verify register button displayed
     */
    public boolean isRegisterButtonDisplayed() {

        return isDisplayed(registerButton);
    }

    /**
     * Verify hero section displayed
     */
    public boolean isHeroSectionDisplayed() {

        return isDisplayed(heroSection);
    }

    /**
     * Verify logout successful
     */
    public void verifyLogoutSuccessful() {

        Assert.assertTrue(
                isLoginButtonDisplayed(),
                "Login button not displayed after logout");

        Assert.assertTrue(
                isRegisterButtonDisplayed(),
                "Register button not displayed after logout");

        Assert.assertTrue(
                isHeroSectionDisplayed(),
                "Landing page not displayed after logout");
    }

    /**
     * Complete logout flow
     */
    public void performLogout()
            throws InterruptedException {

        Thread.sleep(3000);

        logout();

        verifyLogoutSuccessful();

        System.out.println(
                "User logged out successfully");
    }
}