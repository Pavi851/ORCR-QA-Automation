package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class BasePage {

    protected WebDriver driver;
    protected WebDriverWait wait;

    public BasePage(WebDriver driver) {

        this.driver = driver;

        this.wait =
                new WebDriverWait(
                        driver,
                        Duration.ofSeconds(15));
    }

    protected WebElement getElement(By locator) {

        return wait.until(
                ExpectedConditions.visibilityOfElementLocated(locator));
    }

    protected void waitForVisibility(By locator) {

        wait.until(
                ExpectedConditions.visibilityOfElementLocated(locator));
    }

    protected void waitForClickable(By locator) {

        wait.until(
                ExpectedConditions.elementToBeClickable(locator));
    }

    protected void click(By locator) {

        waitForClickable(locator);

        getElement(locator).click();
    }

    protected void jsClick(By locator) {

        WebElement element =
                getElement(locator);

        JavascriptExecutor js =
                (JavascriptExecutor) driver;

        js.executeScript(
                "arguments[0].scrollIntoView({block:'center'});",
                element);

        js.executeScript(
                "arguments[0].click();",
                element);
    }

    protected void type(By locator,
                        String value) {

        WebElement element =
                getElement(locator);

        element.clear();

        element.sendKeys(value);
    }

    protected String getText(By locator) {

        return getElement(locator).getText();
    }

    protected boolean isDisplayed(By locator) {

        try {

            return getElement(locator).isDisplayed();

        } catch (Exception e) {

            return false;
        }
    }

    protected void selectByVisibleText(
            By locator,
            String value) {

        Select select =
                new Select(getElement(locator));

        select.selectByVisibleText(value);
    }

    protected void uploadFile(
            By locator,
            String filePath) {

        getElement(locator)
                .sendKeys(filePath);
    }

    protected void scrollToElement(By locator) {

        WebElement element =
                getElement(locator);

        JavascriptExecutor js =
                (JavascriptExecutor) driver;

        js.executeScript(
                "arguments[0].scrollIntoView({block:'center'});",
                element);
    }

    protected void waitForSeconds(int seconds) {

        try {

            Thread.sleep(seconds * 1000L);

        } catch (InterruptedException e) {

            Thread.currentThread().interrupt();
        }
    }
}