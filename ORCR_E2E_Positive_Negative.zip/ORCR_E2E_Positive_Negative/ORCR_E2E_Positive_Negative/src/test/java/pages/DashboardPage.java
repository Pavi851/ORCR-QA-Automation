package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class DashboardPage extends BasePage {

    public DashboardPage(WebDriver driver) {
        super(driver);
    }

    private final By buyPolicy =
            By.id("navPolicies");

    private final By claims =
            By.id("navClaims");

    private final By documents =
            By.id("documentsTab");

    private final By logout =
            By.id("logoutBtn");

    private final By welcomeHeading =
            By.id("welcomeHeading");

    public void clickBuyPolicy() {
        click(buyPolicy);
    }

    public void clickClaims() {

        waitForSeconds(2);

        scrollToElement(claims);

        waitForSeconds(1);

        jsClick(claims);
    }

    public void clickDocuments() {

        waitForSeconds(2);

        ((org.openqa.selenium.JavascriptExecutor) driver)
                .executeScript("window.scrollTo(0,0);");

        waitForSeconds(1);

        scrollToElement(documents);

        waitForSeconds(1);

        jsClick(documents);
    }

    public void clickLogout() {
        click(logout);
    }

    public boolean verifyDashboardLoaded() {
        return isDisplayed(welcomeHeading);
    }

    public void waitForDashboardToLoad() {

        waitForVisibility(By.id("navClaims"));

        waitForSeconds(2);
    }
}