package stepdefinitions;

import hooks.Hooks;
import io.cucumber.java.en.*;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import pages.*;

public class InsuranceSteps {

    private final WebDriver driver = Hooks.driver;

    private DashboardPage dashboardPage;
    private BuyPolicyPage buyPolicyPage;
    private ClaimsPage claimsPage;
    private DocumentsPage documentsPage;
    private LogoutPage logoutPage;

    private String policyNumber;
    private String applicationReference;
    private String claimReference;

    // =====================================================
    // COMMON SETUP
    // =====================================================

    @Given("User opens PolicyDekho portal")
    public void userOpensPolicyDekhoPortal() {

        dashboardPage = new DashboardPage(driver);
        buyPolicyPage = new BuyPolicyPage(driver);
        claimsPage = new ClaimsPage(driver);
        documentsPage = new DocumentsPage(driver);
        logoutPage = new LogoutPage(driver);

        Assert.assertTrue(
                dashboardPage.verifyDashboardLoaded(),
                "Dashboard not loaded");
    }

    // =====================================================
    // POSITIVE E2E FLOW
    // =====================================================

    @When("User purchases a health insurance policy")
    public void userPurchasesHealthInsurancePolicy() {

        dashboardPage.clickBuyPolicy();

        buyPolicyPage.purchaseHealthInsurancePolicy();
    }

    @Then("Policy should be generated successfully")
    public void policyShouldBeGeneratedSuccessfully()
            throws InterruptedException {

        Thread.sleep(3000);

        policyNumber =
                buyPolicyPage.getPolicyNumber();

        applicationReference =
                buyPolicyPage.getApplicationReference();

        Assert.assertNotNull(
                policyNumber,
                "Policy Number is null");

        Assert.assertFalse(
                policyNumber.trim().isEmpty(),
                "Policy Number not generated");

        Assert.assertNotNull(
                applicationReference,
                "Application Reference is null");

        Assert.assertFalse(
                applicationReference.trim().isEmpty(),
                "Application Reference not generated");

        System.out.println(
                "Policy Number : "
                        + policyNumber);

        System.out.println(
                "Application Reference : "
                        + applicationReference);

        buyPolicyPage.navigateToDashboard();

        Thread.sleep(3000);
    }

    @When("User submits a hospitalization claim")
    public void userSubmitsHospitalizationClaim() {

        dashboardPage.clickClaims();

        String documentPath =
                System.getProperty("user.home")
                        + "\\Downloads\\sample.docx";

        claimsPage.createNewClaim(documentPath);
    }

    @Then("Claim should be submitted successfully")
    public void claimShouldBeSubmittedSuccessfully() {

        Assert.assertTrue(
                claimsPage.verifyClaimSubmitted(),
                "Claim submission failed");

        claimReference =
                claimsPage.getClaimReferenceNumber();

        Assert.assertNotNull(
                claimReference,
                "Claim Reference is null");

        Assert.assertFalse(
                claimReference.trim().isEmpty(),
                "Claim Reference not generated");

        System.out.println(
                "Claim Reference : "
                        + claimReference);
    }

    @When("User uploads a medical document")
    public void userUploadsMedicalDocument() {

        String pdfPath =
                System.getProperty("user.home")
                        + "\\Downloads\\sample.pdf";

        documentsPage.uploadMedicalReport(pdfPath);
    }

    @Then("Document should be uploaded successfully")
    public void documentShouldBeUploadedSuccessfully() {

        Assert.assertTrue(
                documentsPage.verifyUploadSuccess(),
                "Upload failed");

        Assert.assertTrue(
                documentsPage.verifyDocumentsTable(),
                "Documents table not displayed");

        Assert.assertTrue(
                documentsPage.verifyUploadedDocumentExists(),
                "Uploaded document not found");

        System.out.println(
                "Document Uploaded Successfully");
    }

    @When("User navigates to dashboard")
    public void userNavigatesToDashboard() {

        logoutPage.navigateToDashboard();

        Assert.assertTrue(
                dashboardPage.verifyDashboardLoaded(),
                "Dashboard navigation failed");
    }

    @And("User logs out")
    public void userLogsOut()
            throws InterruptedException {

        logoutPage.performLogout();
    }

    @Then("User should be logged out successfully")
    public void userShouldBeLoggedOutSuccessfully() {

        Assert.assertTrue(
                logoutPage.isLoginButtonDisplayed(),
                "Login button not displayed");

        Assert.assertTrue(
                logoutPage.isRegisterButtonDisplayed(),
                "Register button not displayed");

        Assert.assertTrue(
                logoutPage.isHeroSectionDisplayed(),
                "Hero section not displayed");

        System.out.println(
                "Logout Successful");
    }

    // =====================================================
    // NEGATIVE SCENARIO 1
    // UNDERAGE APPLICANT
    // =====================================================

    @When("User purchases a health insurance policy with underage DOB")
    public void userPurchasesHealthInsurancePolicyWithUnderageDOB() {

        dashboardPage.clickBuyPolicy();

        buyPolicyPage.purchasePolicyWithUnderageDOB();
    }

    @Then("Age validation message should be displayed")
    public void ageValidationMessageShouldBeDisplayed() {

        Assert.assertTrue(
                driver.getPageSource().contains("18")
                        || driver.getPageSource().contains("45")
                        || driver.getPageSource().contains("age"),
                "Age validation message not displayed");

        System.out.println(
                "PASS - Age validation verified");
    }

    // =====================================================
    // NEGATIVE SCENARIO 2
    // FUTURE INCIDENT DATE
    // =====================================================

    @When("User purchases a valid health insurance policy")
    public void userPurchasesAValidHealthInsurancePolicy() {

        dashboardPage.clickBuyPolicy();

        buyPolicyPage.purchaseHealthInsurancePolicy();

        buyPolicyPage.navigateToDashboard();
    }

    @And("User files a claim with future incident date")
    public void userFilesAClaimWithFutureIncidentDate() {

        dashboardPage.clickClaims();

        claimsPage.createClaimWithFutureIncidentDate();
    }

    @Then("Future incident date validation should be displayed")
    public void futureIncidentDateValidationShouldBeDisplayed() {

        Assert.assertTrue(
                claimsPage.isStillOnClaimStep1(),
                "User proceeded with future incident date");

        System.out.println(
                "PASS - Future incident date blocked");
    }

    // =====================================================
    // NEGATIVE SCENARIO 3
    // CLAIM WITHOUT DECLARATION
    // =====================================================

    @And("User submits claim without accepting declaration")
    public void userSubmitsClaimWithoutAcceptingDeclaration() {

        dashboardPage.clickClaims();

        claimsPage.createClaimWithoutDeclaration();
    }

    @Then("Claim submission should be blocked")
    public void claimSubmissionShouldBeBlocked() {

        Assert.assertFalse(
                driver.getPageSource()
                        .contains("Claim Submitted Successfully"),
                "Claim submitted without declaration");

        System.out.println(
                "PASS - Claim blocked successfully");
    }

    // =====================================================
    // NEGATIVE SCENARIO 4
    // INVALID FILE UPLOAD
    // =====================================================

    @When("User uploads unsupported file type")
    public void userUploadsUnsupportedFileType() {

        dashboardPage.clickClaims();

        claimsPage.openDocumentsTab();

        String invalidFile =
                System.getProperty("user.home")
                        + "\\Downloads\\sample.txt";

        documentsPage.uploadDocument(invalidFile);
    }

    @Then("Invalid file upload validation should be displayed")
    public void invalidFileUploadValidationShouldBeDisplayed() {

        String pageText =
                driver.findElement(
                                org.openqa.selenium.By.tagName("body"))
                        .getText();

        System.out.println(
                "===== DOCUMENT PAGE TEXT =====");

        System.out.println(pageText);

        System.out.println(
                "===== DOCUMENT PAGE TEXT END =====");

        Assert.fail(
                "Check actual validation text in console");
    }

    // =====================================================
    // NEGATIVE SCENARIO 5
    // DASHBOARD ACCESS AFTER LOGOUT
    // =====================================================

    @Given("User has logged out successfully")
    public void userHasLoggedOutSuccessfully()
            throws InterruptedException {

        logoutPage.performLogout();
    }

    @When("User clicks browser back button")
    public void userClicksBrowserBackButton() {

        driver.navigate().back();
    }

    @Then("Dashboard should not be accessible")
    public void dashboardShouldNotBeAccessible() {

        Assert.assertFalse(
                driver.getCurrentUrl()
                        .contains("dashboard"),
                "Dashboard accessible after logout");

        System.out.println(
                "PASS - Dashboard access blocked after logout");
    }

    //Negative 6

    @When("User creates a claim without claim amount")
    public void userCreatesAClaimWithoutClaimAmount() {

        dashboardPage.clickClaims();

        claimsPage.createClaimWithoutAmount();
    }

    @Then("Claim amount validation should be displayed")
    public void claimAmountValidationShouldBeDisplayed() {

        String pageText =
                driver.findElement(
                                By.tagName("body"))
                        .getText();

        System.out.println(pageText);

        Assert.assertTrue(
                pageText.toLowerCase().contains("claim")
                        || pageText.toLowerCase().contains("amount")
                        || pageText.toLowerCase().contains("required"),
                "Claim amount validation not displayed");

        System.out.println(
                "PASS - Claim Amount Validation Verified");
    }
}